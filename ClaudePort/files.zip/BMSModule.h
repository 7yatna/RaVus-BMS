#pragma once
/*
 * BMSModule.h - Tesla Model S BMS module driver
 * STM32F103 port of TeslaBMSV2
 *
 * Each BMS module (Tesla Gen2) has 6 cells and communicates over a
 * daisy-chained single-wire UART at 612500 baud.
 */

#ifndef BMSMODULE_H
#define BMSMODULE_H

#include <stdint.h>
#include <stdbool.h>
#include "config.h"

/* BMS module register map */
#define REG_DEV_STATUS      0x00
#define REG_GPAI            0x01
#define REG_VCELL1          0x02
#define REG_VCELL2          0x03
#define REG_VCELL3          0x04
#define REG_VCELL4          0x05
#define REG_VCELL5          0x06
#define REG_VCELL6          0x07
#define REG_TEMPERATURE1    0x08
#define REG_TEMPERATURE2    0x09
#define REG_ALERT_STATUS    0x20
#define REG_FAULT_STATUS    0x21
#define REG_CBAL_TIME       0x22
#define REG_DEVICE_CTRL     0x31
#define REG_ADC_CTRL        0x32
#define REG_IO_CTRL         0x33
#define REG_BAL_CTRL        0x34
#define REG_BAL_TIME        0x35
#define REG_ADC_CONV        0x36
#define REG_ADDR_CTRL       0x3B

/* Module alert / fault bit masks */
#define ALERT_OV            (1 << 0)   /* over voltage      */
#define ALERT_UV            (1 << 1)   /* under voltage     */
#define ALERT_OT            (1 << 2)   /* over temperature  */
#define ALERT_UT            (1 << 3)   /* under temperature */
#define ALERT_EEPROM        (1 << 6)
#define ALERT_CBALSTAT      (1 << 7)

/* Cell balancing bit masks (one bit per cell, bits 0..5) */
#define BAL_ALL_CELLS       0x3F

#ifdef __cplusplus

class BMSModule {
public:
    BMSModule();

    /* --- Identification --- */
    void     setAddress(uint8_t addr)  { address = addr; }
    uint8_t  getAddress(void) const    { return address; }
    void     setExists(bool e)         { exists = e; }
    bool     isExisting(void) const    { return exists; }
    void     setFault(bool f)          { fault = f; }
    bool     isFaulty(void) const      { return fault; }

    /* --- Data accessors --- */
    float    getCellVoltage(uint8_t cell) const;
    float    getModuleVoltage(void) const;
    float    getHighCellVolt(void) const;
    float    getLowCellVolt(void) const;
    float    getAvgCellVolt(void) const;
    float    getTemperature(uint8_t sensor) const;  /* sensor 0 or 1 */
    float    getAvgTemperature(void) const;

    /* --- Raw data storage (populated by BMSModuleManager) --- */
    uint16_t cellVoltageRaw[MAX_CELLS_PER_MODULE]; /* raw ADC counts      */
    uint16_t temperatureRaw[2];                    /* raw ADC counts      */
    uint8_t  alertStatus;
    uint8_t  faultStatus;
    uint8_t  balanceStatus;                        /* which cells balance */
    bool     balancing;

    /* Conversion helpers */
    static float rawToVoltage(uint16_t raw);       /* ADC → volts         */
    static float rawToTemp(uint16_t raw);          /* ADC → °C            */

private:
    uint8_t  address;
    bool     exists;
    bool     fault;
};

#endif /* __cplusplus */
#endif /* BMSMODULE_H */
