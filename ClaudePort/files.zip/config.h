#pragma once
/*
 * config.h - TeslaBMSV2 ported to STM32F103C8T6 (Blue Pill)
 * Target:   STM32F103C8T6 @ 72MHz
 * Toolchain: libopencm3 + libopeninv
 *
 * Original: https://github.com/Tom-evnut/TeslaBMSV2
 * Ported for STM32F103 (Blue Pill) using libopencm3
 */

#ifndef CONFIG_H
#define CONFIG_H

#include <stdint.h>
#include <stdbool.h>

/* -----------------------------------------------------------------------
 * Hardware pin mapping (STM32F103C8T6 Blue Pill)
 * -----------------------------------------------------------------------
 * USART1  TX = PA9   RX = PA10   (debug / serial console, 115200 baud)
 * USART2  TX = PA2   RX = PA3    (BMS module UART, 612500 baud)
 * CAN1    TX = PB9   RX = PB8    (Victron/SMA CAN bus, 500 kbps)
 * ADC     PA0                    (current sensor input)
 * GPIO    PB0  = CHARGE_ENABLE
 * GPIO    PB1  = DISCHARGE_ENABLE
 * GPIO    PC13 = ONBOARD_LED (Blue Pill built-in LED, active LOW)
 * ----------------------------------------------------------------------- */

#define USART_DEBUG          USART1
#define USART_DEBUG_BAUD     115200
#define USART_DEBUG_PORT     GPIOA
#define USART_DEBUG_TX_PIN   GPIO9
#define USART_DEBUG_RX_PIN   GPIO10

#define USART_BMS            USART2
#define USART_BMS_BAUD       612500
#define USART_BMS_PORT       GPIOA
#define USART_BMS_TX_PIN     GPIO2
#define USART_BMS_RX_PIN     GPIO3

#define GPIO_CHARGE_PORT     GPIOB
#define GPIO_CHARGE_PIN      GPIO0

#define GPIO_DISCHARGE_PORT  GPIOB
#define GPIO_DISCHARGE_PIN   GPIO1

#define GPIO_LED_PORT        GPIOC
#define GPIO_LED_PIN         GPIO13   /* active LOW on Blue Pill */

#define ADC_CURRENT_PORT     GPIOA
#define ADC_CURRENT_PIN      GPIO0    /* ADC12_IN0 */
#define ADC_CURRENT_CHANNEL  0

/* -----------------------------------------------------------------------
 * BMS module limits (defaults — overrideable via serial console)
 * ----------------------------------------------------------------------- */
#define MAX_MODULES          16       /* maximum number of BMS modules     */
#define MAX_CELLS_PER_MODULE 6        /* Tesla Model S module: 6 cells     */
#define MAX_MODULE_ADDR      0x3F     /* 6-bit address space               */

/* Cell voltage limits (mV * 1 = raw mV) */
#define DEFAULT_OVER_VOLT    4200     /* over-voltage threshold (mV)       */
#define DEFAULT_UNDER_VOLT   3000     /* under-voltage threshold (mV)      */
#define DEFAULT_BALANCE_VOLT 4100     /* cell balancing start voltage (mV) */
#define DEFAULT_BALANCE_DIFF 20       /* balance if delta > N mV           */

/* Temperature limits (°C) */
#define DEFAULT_OVER_TEMP    55       /* over-temperature threshold        */
#define DEFAULT_UNDER_TEMP  -20       /* under-temperature threshold       */

/* Current sensor (hall-effect, 0–3.3 V → -xxx to +xxx A) */
#define DEFAULT_CURRENT_OFFSET   1650 /* zero-current ADC midpoint (mV)   */
#define DEFAULT_CURRENT_GAIN     66   /* mV/A sensitivity                  */

/* Pack configuration */
#define DEFAULT_SERIES_CELLS     24   /* number of cells in series         */
#define DEFAULT_PARALLEL_STRINGS  1   /* parallel strings                  */
#define DEFAULT_CAPACITY_AH      74   /* nominal pack capacity (Ah)        */

/* Timing */
#define LOOP_PERIOD_MS           100  /* main loop period (ms)             */
#define BALANCE_CHECK_MS         1000 /* balancing check interval (ms)     */
#define CAN_TX_PERIOD_MS         1000 /* CAN heartbeat period (ms)         */

/* -----------------------------------------------------------------------
 * EEPROM emulation page addresses (STM32F103 Flash-based EEPROM)
 * ----------------------------------------------------------------------- */
#define EEPROM_PAGE0_ADDR    0x0801F000
#define EEPROM_PAGE1_ADDR    0x0801F800
#define SETTINGS_MAGIC       0xDEADBEEF
#define SETTINGS_VERSION     2

/* -----------------------------------------------------------------------
 * CAN IDs (Victron/SMA protocol)
 * ----------------------------------------------------------------------- */
#define CAN_ID_BMS_SOC       0x351
#define CAN_ID_BMS_VOLT      0x355
#define CAN_ID_BMS_TEMP      0x356
#define CAN_ID_BMS_ALARM     0x35A
#define CAN_ID_BMS_STATUS    0x35C

#endif /* CONFIG_H */
