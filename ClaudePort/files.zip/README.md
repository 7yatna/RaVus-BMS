# TeslaBMSV2 — STM32F103C8T6 (Blue Pill) Port

Port of [Tom-evnut/TeslaBMSV2](https://github.com/Tom-evnut/TeslaBMSV2) from
Teensy 3.2 (MK20DX256) to STM32F103C8T6 using **libopencm3**.

---

## Hardware

| Item | Original (Teensy 3.2) | STM32 Port (Blue Pill) |
|---|---|---|
| MCU | NXP MK20DX256 Cortex-M4 | STM32F103C8T6 Cortex-M3 |
| Clock | 96 MHz | 72 MHz |
| Flash | 256 KB | 64 KB |
| RAM | 64 KB | 20 KB |
| FPU | Yes (Cortex-M4) | **No** (soft-float) |

---

## Pin Mapping (Blue Pill)

| Function | Teensy 3.2 | Blue Pill (STM32F103) |
|---|---|---|
| Debug UART TX | Serial (USB) | **PA9** (USART1 TX) |
| Debug UART RX | Serial (USB) | **PA10** (USART1 RX) |
| BMS Bus TX | Serial2 TX | **PA2** (USART2 TX) |
| BMS Bus RX | Serial2 RX | **PA3** (USART2 RX) |
| CAN TX | CAN TX (FlexCAN) | **PB9** (CAN1 TX) |
| CAN RX | CAN RX (FlexCAN) | **PB8** (CAN1 RX) |
| Current Sensor ADC | A0 | **PA0** (ADC_IN0) |
| Charge Enable | Digital out | **PB0** |
| Discharge Enable | Digital out | **PB1** |
| LED | Onboard LED | **PC13** (active LOW) |

> **Note:** CAN1 is remapped to PB8/PB9 (AFIO remap). This is required on
> Blue Pill because the default CAN pins (PA11/PA12) are shared with USB.

---

## Library Dependency Mapping

| Arduino/Teensy Library | STM32 / libopencm3 Equivalent |
|---|---|
| `ADC.h` (pedvide) | `libopencm3/stm32/adc.h` — `adc_read_single()` |
| `FlexCAN.h` | `libopencm3/stm32/can.h` — bxCAN driver |
| `Filters.h` (IIR) | Inline IIR filter in `main.cpp` |
| `EEPROM.h` | Flash page write in `BMSModuleManager.cpp` |
| `IntervalTimer` | SysTick ISR + `system_ms` counter |
| `millis()` | `system_ms` volatile uint32 |
| `delay()` | `delay_ms()` spinning on `system_ms` |
| `Serial.print()` | `logger_log()` / `logger_puts()` via USART1 |
| `Serial2` (BMS bus) | USART2 (PA2/PA3) via libopencm3 |

---

## Key Porting Notes

### Floating Point
The Teensy 3.2 has a hardware FPU; the STM32F103 does not. All `float`
operations will use the soft-float library. This adds ~2–4 µs per operation.
If performance is critical, consider converting temperature/voltage
calculations to fixed-point arithmetic.

### Flash / RAM
The Blue Pill has only 64 KB Flash and 20 KB RAM vs. 256 KB / 64 KB on the
Teensy. Key constraints:
- `MAX_MODULES` is set to 16 in `config.h`. Reduce if RAM is tight.
- The Logger uses a 256-byte stack buffer per call — reduce if needed.
- Avoid `printf`/`sprintf` in interrupt context.

### EEPROM Emulation
The Teensy used `EEPROM.get()` / `EEPROM.put()`. The STM32F103 has no
internal EEPROM, so settings are written directly to a Flash page
(`0x0801F000`). This page is erased and rewritten on each `saveSettings()`
call. For production, use a proper EEPROM emulation library (e.g.
`stm32-eeprom`) for wear levelling.

### CAN Bus
The original used Teensy's `FlexCAN` library. This port uses libopencm3's
`bxCAN` driver configured for 500 kbps (matching Victron/SMA protocol).
The Victron CAN frame format (0x351, 0x355, 0x356, 0x35A, 0x35C) is preserved.

### Current Sensor
The original used Teensy's 16-bit ADC (`adc->adc0->getMaxValue()` = 65535).
The STM32F103 ADC is 12-bit (0–4095). The current calculation in `main.cpp`
is adjusted accordingly. The result is scaled to mV (0–3300) before applying
the gain/offset calibration, so the settings values remain compatible.

### Serial Console
The console command format (`<number><value>`) is identical to the original.
Connect any terminal at **115200 8N1** to PA9/PA10.

---

## Build Instructions

### Prerequisites

```bash
# Install ARM toolchain
sudo apt install gcc-arm-none-eabi binutils-arm-none-eabi

# Clone libopencm3 into the project directory
git clone https://github.com/libopencm3/libopencm3.git
cd libopencm3 && make TARGETS=stm32/f1
cd ..
```

### Build

```bash
make
```

Output files will be in `build/`:
- `TeslaBMS_STM32.elf` — ELF with debug symbols
- `TeslaBMS_STM32.bin` — raw binary for flashing
- `TeslaBMS_STM32.hex` — Intel HEX format

### Flash via ST-Link (OpenOCD)

```bash
make flash
```

### Flash via Black Magic Probe

```bash
make flash_bmp BMP_PORT=/dev/ttyACM0
```

---

## File Structure

```
TeslaBMS_STM32/
├── Makefile
├── README.md
├── include/
│   ├── config.h           — pin map, limits, timing constants
│   ├── Logger.h           — USART1 debug logging
│   ├── BMSModule.h        — single BMS module model
│   ├── BMSModuleManager.h — bus manager, USART2, settings
│   └── SerialConsole.h    — interactive console
└── src/
    ├── main.cpp           — replaces TeslaBMSV2.ino (setup + loop)
    ├── Logger.cpp
    ├── BMSModule.cpp
    ├── BMSModuleManager.cpp
    └── SerialConsole.cpp
```

---

## Serial Console Commands

Connect at **115200 8N1** to PA9 (TX) / PA10 (RX).

| Command | Example | Description |
|---|---|---|
| `1<mV>` | `14200` | Set over-voltage threshold |
| `2<mV>` | `23000` | Set under-voltage threshold |
| `3<mV>` | `34100` | Set balance start voltage |
| `4<mV>` | `420` | Set balance delta |
| `5<°C>` | `555` | Set over-temperature limit |
| `6<Ah>` | `674` | Set pack capacity |
| `7<%>` | `750` | Set SOC manually |
| `8` | `8` | Save settings to Flash |
| `9` | `9` | Reset to defaults |
| `10` | `10` | Re-enumerate BMS modules |
| `11` | `11` | Print full status |
| `12<0-3>` | `123` | Set log level (0=ERR, 3=DBG) |

---

## License

Same as original: see [TeslaBMSV2](https://github.com/Tom-evnut/TeslaBMSV2).
