/*
 * BMSModuleManager.cpp - Tesla BMS module bus manager
 * STM32F103 port of TeslaBMSV2
 *
 * Key replacements vs. Teensy/Arduino original:
 *   Serial2.begin(612500)   → USART2 configured via libopencm3
 *   Serial2.write(buf, len) → usart_send_blocking()
 *   Serial2.readBytes(...)  → usart_recv_blocking() with timeout
 *   EEPROM.get/put()        → Flash-based EEPROM emulation
 *   delay()                 → systick-based delay
 */

#include "BMSModuleManager.h"
#include "Logger.h"
#include <string.h>
#include <stdlib.h>

#include <libopencm3/stm32/rcc.h>
#include <libopencm3/stm32/gpio.h>
#include <libopencm3/stm32/usart.h>
#include <libopencm3/stm32/flash.h>
#include <libopencm3/cm3/systick.h>

/* -----------------------------------------------------------------------
 * Systick-based millisecond counter (set up in main.cpp)
 * ----------------------------------------------------------------------- */
extern volatile uint32_t system_ms;

static void delay_ms(uint32_t ms)
{
    uint32_t end = system_ms + ms;
    while (system_ms < end) { __asm__("nop"); }
}

/* -----------------------------------------------------------------------
 * BMS protocol packet structure
 *
 * [SYNC][LEN][ADDR][REG][DATA...][CRC]
 * SYNC = 0xAA (start-of-frame marker)
 * ----------------------------------------------------------------------- */
#define BMS_SYNC_BYTE   0xAA
#define BMS_BCAST_ADDR  0x3F   /* broadcast address */
#define BMS_RD_FLAG     0x80   /* OR with register to indicate read */
#define BMS_TIMEOUT_MS  50     /* per-byte receive timeout */

/* -----------------------------------------------------------------------
 * CRC-8 (polynomial 0x07 – same as original TeslaBMS)
 * ----------------------------------------------------------------------- */
uint8_t BMSModuleManager::calcCRC(uint8_t *data, uint8_t len)
{
    uint8_t crc = 0;
    for (uint8_t i = 0; i < len; i++) {
        crc ^= data[i];
        for (uint8_t b = 0; b < 8; b++) {
            if (crc & 0x80) crc = (crc << 1) ^ 0x07;
            else            crc <<= 1;
        }
    }
    return crc;
}

/* -----------------------------------------------------------------------
 * USART2 initialisation (replaces Serial2.begin(612500) on Teensy)
 * PA2 = TX (AF push-pull)
 * PA3 = RX (input floating)
 * ----------------------------------------------------------------------- */
void BMSModuleManager::usart_init(void)
{
    rcc_periph_clock_enable(RCC_GPIOA);
    rcc_periph_clock_enable(RCC_USART2);

    gpio_set_mode(GPIOA, GPIO_MODE_OUTPUT_50_MHZ,
                  GPIO_CNF_OUTPUT_ALTFN_PUSHPULL, GPIO2);
    gpio_set_mode(GPIOA, GPIO_MODE_INPUT,
                  GPIO_CNF_INPUT_FLOAT, GPIO3);

    usart_set_baudrate(USART2, USART_BMS_BAUD);
    usart_set_databits(USART2, 8);
    usart_set_stopbits(USART2, USART_STOPBITS_1);
    usart_set_parity(USART2, USART_PARITY_NONE);
    usart_set_mode(USART2, USART_MODE_TX_RX);
    usart_set_flow_control(USART2, USART_FLOWCONTROL_NONE);
    usart_enable(USART2);
}

/* -----------------------------------------------------------------------
 * Low-level: receive one byte with timeout
 * Returns true if a byte was received, false on timeout
 * ----------------------------------------------------------------------- */
static bool usart_recv_timeout(uint32_t timeout_ms, uint8_t *byte_out)
{
    uint32_t deadline = system_ms + timeout_ms;
    while (system_ms < deadline) {
        if (USART_SR(USART2) & USART_SR_RXNE) {
            *byte_out = (uint8_t)usart_recv(USART2);
            return true;
        }
    }
    return false;
}

/* -----------------------------------------------------------------------
 * Low-level: send a packet and optionally receive a response
 *
 * Read frame:  [SYNC][LEN][ADDR|0x80][REG][CRC]
 * Write frame: [SYNC][LEN][ADDR][REG][DATA...][CRC]
 * Response:    [SYNC][LEN][ADDR][REG][DATA...][CRC]
 * ----------------------------------------------------------------------- */
bool BMSModuleManager::sendCommand(uint8_t addr, uint8_t reg,
                                   uint8_t *data, uint8_t len, bool read)
{
    uint8_t pkt[16];
    uint8_t pkt_len;

    /* Flush any stale RX bytes */
    while (USART_SR(USART2) & USART_SR_RXNE) {
        (void)usart_recv(USART2);
    }

    if (read) {
        /* Read command: [SYNC, 2, ADDR|0x80, REG, CRC] */
        pkt[0] = BMS_SYNC_BYTE;
        pkt[1] = 2;                    /* payload bytes after LEN: ADDR + REG */
        pkt[2] = addr | BMS_RD_FLAG;
        pkt[3] = reg;
        pkt[4] = calcCRC(&pkt[1], 3);
        pkt_len = 5;
    } else {
        /* Write command: [SYNC, 2+len, ADDR, REG, data..., CRC] */
        pkt[0] = BMS_SYNC_BYTE;
        pkt[1] = 2 + len;
        pkt[2] = addr;
        pkt[3] = reg;
        memcpy(&pkt[4], data, len);
        pkt[4 + len] = calcCRC(&pkt[1], 3 + len);
        pkt_len = 5 + len;
    }

    /* Transmit packet */
    for (uint8_t i = 0; i < pkt_len; i++) {
        usart_send_blocking(USART2, pkt[i]);
    }

    if (!read) return true;

    /* Receive response: [SYNC, LEN, ADDR, REG, data..., CRC] */
    uint8_t resp[20];
    uint8_t idx = 0;

    /* Wait for SYNC */
    if (!usart_recv_timeout(BMS_TIMEOUT_MS, &resp[idx])) return false;
    if (resp[idx++] != BMS_SYNC_BYTE) return false;

    /* LEN byte */
    if (!usart_recv_timeout(BMS_TIMEOUT_MS, &resp[idx])) return false;
    uint8_t resp_len = resp[idx++];
    if (resp_len > 14) return false;  /* sanity check */

    /* Remaining bytes: ADDR + REG + DATA + CRC = resp_len + 1 bytes */
    uint8_t remaining = resp_len + 1;
    for (uint8_t i = 0; i < remaining; i++) {
        if (!usart_recv_timeout(BMS_TIMEOUT_MS, &resp[idx])) return false;
        idx++;
    }

    /* Verify CRC */
    uint8_t crc_received = resp[idx - 1];
    uint8_t crc_calc     = calcCRC(&resp[1], idx - 2);
    if (crc_received != crc_calc) {
        LOG_WARN("CRC error: got 0x%02X expected 0x%02X", crc_received, crc_calc);
        return false;
    }

    /* Copy data payload into caller's buffer */
    uint8_t data_bytes = resp_len - 2;  /* subtract ADDR and REG */
    if (data_bytes > len) data_bytes = len;
    memcpy(data, &resp[4], data_bytes);

    return true;
}

bool BMSModuleManager::readRegisters(uint8_t addr, uint8_t startReg,
                                     uint8_t count, uint8_t *buf)
{
    /* For multi-register reads we send sequential single-register reads.
     * The Tesla BMS module supports sequential register reads natively
     * by OR-ing the count into the register byte in some implementations,
     * but this safe sequential approach works on all firmware versions. */
    for (uint8_t i = 0; i < count; i++) {
        if (!sendCommand(addr, startReg + i, &buf[i * 2], 2, true)) {
            return false;
        }
    }
    return true;
}

bool BMSModuleManager::writeRegister(uint8_t addr, uint8_t reg, uint8_t value)
{
    return sendCommand(addr, reg, &value, 1, false);
}

/* -----------------------------------------------------------------------
 * Constructor
 * ----------------------------------------------------------------------- */
BMSModuleManager::BMSModuleManager()
    : numModules(0), soc(0.0f), ampSeconds(0.0f), currentAmps(0.0f)
{
    memset(modules, 0, sizeof(modules));
    resetSettings();
}

/* -----------------------------------------------------------------------
 * init() - replaces setup() UART initialisation block
 * ----------------------------------------------------------------------- */
void BMSModuleManager::init(void)
{
    usart_init();
    loadSettings();
    renumberModules();
}

/* -----------------------------------------------------------------------
 * renumberModules()
 * Broadcasts a reset, then walks the daisy-chain assigning addresses 0..N-1
 * (replaces the module enumeration loop in TeslaBMSV2.ino setup())
 * ----------------------------------------------------------------------- */
void BMSModuleManager::renumberModules(void)
{
    LOG_INFO("Enumerating BMS modules...");

    /* Reset all modules to un-addressed state */
    uint8_t reset_val = 0x00;
    sendCommand(BMS_BCAST_ADDR, REG_ADDR_CTRL, &reset_val, 1, false);
    delay_ms(50);

    /* Wake all modules */
    uint8_t wake_val = 0x20;   /* WAKE bit in DEVICE_CTRL */
    sendCommand(BMS_BCAST_ADDR, REG_DEVICE_CTRL, &wake_val, 1, false);
    delay_ms(50);

    numModules = 0;

    /* Walk the chain: each unaddressed module responds to address 0x00
     * and then takes the assigned address */
    for (uint8_t i = 0; i < MAX_MODULES; i++) {
        /* Try to assign address i+1 (addresses start at 1) */
        uint8_t new_addr = i + 1;
        if (!writeRegister(0x00, REG_ADDR_CTRL, new_addr)) break;
        delay_ms(2);

        /* Verify the module is present at its new address */
        uint8_t check[2];
        if (!sendCommand(new_addr, REG_DEV_STATUS, check, 2, true)) break;

        modules[i].setAddress(new_addr);
        modules[i].setExists(true);
        modules[i].setFault(false);
        numModules++;

        LOG_INFO("Found module %d at address 0x%02X", i, new_addr);
    }

    LOG_INFO("Total modules found: %d", numModules);
    settings.numModules = numModules;
}

/* -----------------------------------------------------------------------
 * updateVoltages() - reads all cell voltages from all modules
 * Replaces: bms.readModuleVoltages() / Serial2-based reads in original
 * ----------------------------------------------------------------------- */
void BMSModuleManager::updateVoltages(void)
{
    for (uint8_t m = 0; m < numModules; m++) {
        if (!modules[m].isExisting()) continue;

        uint8_t raw[12];  /* 6 cells × 2 bytes each */
        if (!readRegisters(modules[m].getAddress(), REG_VCELL1, 6, raw)) {
            modules[m].setFault(true);
            LOG_WARN("Failed to read voltages from module %d", m);
            continue;
        }
        modules[m].setFault(false);

        for (uint8_t c = 0; c < MAX_CELLS_PER_MODULE; c++) {
            /* Combine high/low bytes, mask to 14 bits */
            modules[m].cellVoltageRaw[c] =
                (((uint16_t)raw[c * 2] << 8) | raw[c * 2 + 1]) & 0x3FFF;
        }
    }
}

/* -----------------------------------------------------------------------
 * updateTemperatures() - reads temperatures from all modules
 * ----------------------------------------------------------------------- */
void BMSModuleManager::updateTemperatures(void)
{
    for (uint8_t m = 0; m < numModules; m++) {
        if (!modules[m].isExisting()) continue;

        uint8_t raw[4];  /* 2 sensors × 2 bytes */
        if (!readRegisters(modules[m].getAddress(), REG_TEMPERATURE1, 2, raw)) {
            LOG_WARN("Failed to read temperature from module %d", m);
            continue;
        }

        modules[m].temperatureRaw[0] =
            (((uint16_t)raw[0] << 8) | raw[1]) & 0x3FFF;
        modules[m].temperatureRaw[1] =
            (((uint16_t)raw[2] << 8) | raw[3]) & 0x3FFF;
    }
}

/* -----------------------------------------------------------------------
 * updateBalanceStatus() - reads balancing status from all modules
 * ----------------------------------------------------------------------- */
void BMSModuleManager::updateBalanceStatus(void)
{
    for (uint8_t m = 0; m < numModules; m++) {
        if (!modules[m].isExisting()) continue;

        uint8_t status[2];
        if (sendCommand(modules[m].getAddress(), REG_ALERT_STATUS, status, 2, true)) {
            modules[m].alertStatus = status[0];
        }
        if (sendCommand(modules[m].getAddress(), REG_FAULT_STATUS, status, 2, true)) {
            modules[m].faultStatus = status[0];
        }
    }
}

/* -----------------------------------------------------------------------
 * balanceCells() - enable/disable cell balancing across the pack
 * ----------------------------------------------------------------------- */
void BMSModuleManager::balanceCells(bool enable)
{
    if (!enable) {
        stopBalancing();
        return;
    }

    float highV = getHighCellVolt();
    float lowV  = getLowCellVolt();
    float delta = highV - lowV;

    float balV = (float)settings.balanceVoltage / 1000.0f;
    float balDiff = (float)settings.balanceDiff / 1000.0f;

    if (highV < balV || delta < balDiff) {
        stopBalancing();
        return;
    }

    for (uint8_t m = 0; m < numModules; m++) {
        if (!modules[m].isExisting()) continue;

        uint8_t cellMask = 0;
        for (uint8_t c = 0; c < MAX_CELLS_PER_MODULE; c++) {
            float v = modules[m].getCellVoltage(c);
            if ((v - lowV) > balDiff) {
                cellMask |= (1 << c);
            }
        }

        if (cellMask) {
            setBalancing(modules[m].getAddress(), cellMask);
            modules[m].balancing = true;
            modules[m].balanceStatus = cellMask;
        } else {
            writeRegister(modules[m].getAddress(), REG_BAL_CTRL, 0x00);
            modules[m].balancing = false;
        }
    }
}

void BMSModuleManager::setBalancing(uint8_t moduleAddr, uint8_t cellMask)
{
    writeRegister(moduleAddr, REG_BAL_CTRL, cellMask & BAL_ALL_CELLS);
}

void BMSModuleManager::stopBalancing(void)
{
    for (uint8_t m = 0; m < numModules; m++) {
        if (!modules[m].isExisting()) continue;
        writeRegister(modules[m].getAddress(), REG_BAL_CTRL, 0x00);
        modules[m].balancing = false;
        modules[m].balanceStatus = 0;
    }
}

/* -----------------------------------------------------------------------
 * Pack-level aggregates
 * ----------------------------------------------------------------------- */
float BMSModuleManager::getPackVoltage(void) const
{
    float total = 0.0f;
    for (uint8_t m = 0; m < numModules; m++) {
        if (modules[m].isExisting() && !modules[m].isFaulty()) {
            total += modules[m].getModuleVoltage();
        }
    }
    return total;
}

float BMSModuleManager::getHighCellVolt(void) const
{
    float high = 0.0f;
    for (uint8_t m = 0; m < numModules; m++) {
        if (!modules[m].isExisting()) continue;
        float v = modules[m].getHighCellVolt();
        if (v > high) high = v;
    }
    return high;
}

float BMSModuleManager::getLowCellVolt(void) const
{
    float low = 9999.0f;
    for (uint8_t m = 0; m < numModules; m++) {
        if (!modules[m].isExisting()) continue;
        float v = modules[m].getLowCellVolt();
        if (v < low) low = v;
    }
    return (low == 9999.0f) ? 0.0f : low;
}

float BMSModuleManager::getAvgCellVolt(void) const
{
    if (numModules == 0) return 0.0f;
    float sum = 0.0f;
    uint8_t count = 0;
    for (uint8_t m = 0; m < numModules; m++) {
        if (!modules[m].isExisting()) continue;
        sum += modules[m].getAvgCellVolt();
        count++;
    }
    return (count > 0) ? (sum / count) : 0.0f;
}

float BMSModuleManager::getHighTemperature(void) const
{
    float high = -999.0f;
    for (uint8_t m = 0; m < numModules; m++) {
        if (!modules[m].isExisting()) continue;
        float t = modules[m].getAvgTemperature();
        if (t > high) high = t;
    }
    return high;
}

float BMSModuleManager::getLowTemperature(void) const
{
    float low = 999.0f;
    for (uint8_t m = 0; m < numModules; m++) {
        if (!modules[m].isExisting()) continue;
        float t = modules[m].getAvgTemperature();
        if (t < low) low = t;
    }
    return low;
}

float BMSModuleManager::getAvgTemperature(void) const
{
    if (numModules == 0) return 0.0f;
    float sum = 0.0f;
    uint8_t count = 0;
    for (uint8_t m = 0; m < numModules; m++) {
        if (!modules[m].isExisting()) continue;
        sum += modules[m].getAvgTemperature();
        count++;
    }
    return (count > 0) ? (sum / count) : 0.0f;
}

/* -----------------------------------------------------------------------
 * Fault checks
 * ----------------------------------------------------------------------- */
bool BMSModuleManager::hasOverVoltage(void) const
{
    float limit = (float)settings.overVoltage / 1000.0f;
    return getHighCellVolt() > limit;
}

bool BMSModuleManager::hasUnderVoltage(void) const
{
    float limit = (float)settings.underVoltage / 1000.0f;
    return getLowCellVolt() < limit;
}

bool BMSModuleManager::hasOverTemp(void) const
{
    return getHighTemperature() > (float)settings.overTemp;
}

bool BMSModuleManager::hasUnderTemp(void) const
{
    return getLowTemperature() < (float)settings.underTemp;
}

bool BMSModuleManager::hasFault(void) const
{
    for (uint8_t m = 0; m < numModules; m++) {
        if (modules[m].isFaulty()) return true;
    }
    return hasOverVoltage() || hasUnderVoltage() ||
           hasOverTemp()    || hasUnderTemp();
}

/* -----------------------------------------------------------------------
 * Settings: Flash EEPROM emulation
 * Replaces: EEPROM.get() / EEPROM.put() from Teensy
 *
 * Uses a simple write-once approach: the last valid settings block
 * at EEPROM_PAGE0_ADDR is the active one. For production use consider
 * a proper EE emulation library (e.g. stm32-eeprom-emulation).
 * ----------------------------------------------------------------------- */
void BMSModuleManager::resetSettings(void)
{
    settings.magic           = SETTINGS_MAGIC;
    settings.version         = SETTINGS_VERSION;
    settings.overVoltage     = DEFAULT_OVER_VOLT;
    settings.underVoltage    = DEFAULT_UNDER_VOLT;
    settings.balanceVoltage  = DEFAULT_BALANCE_VOLT;
    settings.balanceDiff     = DEFAULT_BALANCE_DIFF;
    settings.overTemp        = DEFAULT_OVER_TEMP;
    settings.underTemp       = DEFAULT_UNDER_TEMP;
    settings.currentOffset   = DEFAULT_CURRENT_OFFSET;
    settings.currentGainLow  = 660;    /* 66.0 mV/A × 10 */
    settings.currentGainHigh = 660;
    settings.currentDeadband = 10;
    settings.numModules      = 0;
    settings.parallelStrings = DEFAULT_PARALLEL_STRINGS;
    settings.packCapacityAh  = DEFAULT_CAPACITY_AH;
    settings.socVolt[0]      = 3000;   /* 0% at 3.000 V */
    settings.socVolt[1]      = 0;
    settings.socVolt[2]      = 4150;   /* 100% at 4.150 V */
    settings.socVolt[3]      = 1000;
    settings.canDevice       = 0;      /* Victron */
}

void BMSModuleManager::loadSettings(void)
{
    const BMSSettings *flash_ptr = (const BMSSettings *)EEPROM_PAGE0_ADDR;

    if (flash_ptr->magic != SETTINGS_MAGIC ||
        flash_ptr->version != SETTINGS_VERSION) {
        LOG_WARN("No valid settings in Flash, using defaults");
        resetSettings();
        return;
    }

    memcpy(&settings, flash_ptr, sizeof(BMSSettings));
    LOG_INFO("Settings loaded from Flash");
}

void BMSModuleManager::saveSettings(void)
{
    flash_unlock();

    /* Erase the page */
    flash_erase_page(EEPROM_PAGE0_ADDR);

    /* Write settings word by word */
    const uint32_t *src = (const uint32_t *)&settings;
    uint32_t dst_addr   = EEPROM_PAGE0_ADDR;
    uint32_t num_words  = (sizeof(BMSSettings) + 3) / 4;

    for (uint32_t i = 0; i < num_words; i++) {
        flash_program_word(dst_addr, src[i]);
        dst_addr += 4;
    }

    flash_lock();
    LOG_INFO("Settings saved to Flash");
}
