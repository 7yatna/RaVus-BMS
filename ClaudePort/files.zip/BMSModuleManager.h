#pragma once
/*
 * BMSModuleManager.h - Manages all Tesla BMS modules on the daisy-chain bus
 * STM32F103 port of TeslaBMSV2
 *
 * The Tesla BMS modules communicate over a single-wire UART daisy-chain
 * at 612500 baud using USART2 (PA2/PA3 on the Blue Pill).
 *
 * Replaces: Arduino Serial2 (Teensy) → libopencm3 USART2
 */

#ifndef BMSMODULEMANAGER_H
#define BMSMODULEMANAGER_H

#include <stdint.h>
#include <stdbool.h>
#include "BMSModule.h"
#include "config.h"

/* Settings structure (persisted to Flash EEPROM emulation) */
typedef struct {
    uint32_t magic;
    uint16_t version;

    /* Cell limits (mV stored as uint16) */
    uint16_t overVoltage;       /* mV */
    uint16_t underVoltage;      /* mV */
    uint16_t balanceVoltage;    /* mV - start balancing above this */
    uint16_t balanceDiff;       /* mV - balance if delta exceeds this */

    /* Temperature limits */
    int16_t  overTemp;          /* °C */
    int16_t  underTemp;         /* °C */

    /* Current sensor calibration */
    int16_t  currentOffset;     /* mV at zero current */
    uint16_t currentGainLow;    /* mV/A × 10000 for low-range */
    uint16_t currentGainHigh;   /* mV/A × 10000 for high-range */
    uint16_t currentDeadband;   /* mV - treat as zero current below this */

    /* Pack geometry */
    uint8_t  numModules;        /* detected / configured module count */
    uint8_t  parallelStrings;   /* parallel strings */
    uint16_t packCapacityAh;    /* nominal capacity in Ah */

    /* SOC voltage map (4 points: low_soc_v, low_soc%, high_soc_v, high_soc%) */
    uint16_t socVolt[4];

    /* CAN device selection */
    uint8_t  canDevice;         /* 0=Victron, 1=SMA, 2=BMS CAN */

    uint8_t  padding[6];        /* align to 4 bytes */
} BMSSettings;

#ifdef __cplusplus

class BMSModuleManager {
public:
    BMSModuleManager();

    /* Initialise USART2 bus and discover modules */
    void     init(void);

    /* Enumerate and address modules on the bus */
    void     renumberModules(void);

    /* Read all cell voltages and temperatures from all modules */
    void     updateVoltages(void);
    void     updateTemperatures(void);
    void     updateBalanceStatus(void);

    /* Balancing control */
    void     balanceCells(bool enable);
    void     setBalancing(uint8_t moduleAddr, uint8_t cellMask);
    void     stopBalancing(void);

    /* Pack-level aggregates */
    float    getPackVoltage(void) const;
    float    getHighCellVolt(void) const;
    float    getLowCellVolt(void) const;
    float    getAvgCellVolt(void) const;
    float    getHighTemperature(void) const;
    float    getLowTemperature(void) const;
    float    getAvgTemperature(void) const;
    uint8_t  getNumModules(void) const  { return numModules; }
    float    getCellDelta(void) const   { return getHighCellVolt() - getLowCellVolt(); }

    /* Alert / fault status */
    bool     hasOverVoltage(void) const;
    bool     hasUnderVoltage(void) const;
    bool     hasOverTemp(void) const;
    bool     hasUnderTemp(void) const;
    bool     hasFault(void) const;

    /* Module access */
    BMSModule& getModule(uint8_t idx)   { return modules[idx]; }

    /* Settings */
    BMSSettings settings;
    void     loadSettings(void);
    void     saveSettings(void);
    void     resetSettings(void);

    /* SOC tracking */
    float    getSOC(void) const         { return soc; }
    void     setSOC(float s)            { soc = s; }
    float    getAmpseconds(void) const  { return ampSeconds; }
    void     addAmpseconds(float as)    { ampSeconds += as; }

    /* Current (set externally from ADC reading) */
    float    getCurrent(void) const     { return currentAmps; }
    void     setCurrent(float a)        { currentAmps = a; }

private:
    BMSModule modules[MAX_MODULES];
    uint8_t   numModules;
    float     soc;
    float     ampSeconds;
    float     currentAmps;

    /* Low-level USART2 communication */
    void     usart_init(void);
    bool     sendCommand(uint8_t addr, uint8_t reg, uint8_t *data, uint8_t len, bool read);
    bool     readRegisters(uint8_t addr, uint8_t startReg, uint8_t count, uint8_t *buf);
    bool     writeRegister(uint8_t addr, uint8_t reg, uint8_t value);

    /* CRC helper */
    static uint8_t calcCRC(uint8_t *data, uint8_t len);
};

#endif /* __cplusplus */
#endif /* BMSMODULEMANAGER_H */
