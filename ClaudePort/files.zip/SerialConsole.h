#pragma once
/*
 * SerialConsole.h - Interactive serial console over USART1
 * STM32F103 port of TeslaBMSV2
 *
 * Replaces: Arduino Serial (debug), Serial.read(), Serial.print()
 * Uses: libopencm3 USART1 (PA9/PA10) @ 115200 baud
 */

#ifndef SERIALCONSOLE_H
#define SERIALCONSOLE_H

#include <stdint.h>
#include <stdbool.h>
#include "BMSModuleManager.h"
#include "config.h"

#define CONSOLE_BUF_LEN  80

#ifdef __cplusplus

class SerialConsole {
public:
    SerialConsole(BMSModuleManager &bms_ref);

    void init(void);
    void handleByte(uint8_t c);   /* call this for each received byte */
    void tick(void);              /* call each main loop iteration     */
    void printMenu(void);
    void printStatus(void);

private:
    BMSModuleManager &bms;

    char     rxBuf[CONSOLE_BUF_LEN];
    uint8_t  rxIdx;
    bool     commandReady;

    void processCommand(void);
    void printFloat(float val, uint8_t decimals);
    void printHelp(void);

    /* Command handlers */
    void cmdSetOverVolt(const char *arg);
    void cmdSetUnderVolt(const char *arg);
    void cmdSetBalVolt(const char *arg);
    void cmdSetBalDiff(const char *arg);
    void cmdSetOverTemp(const char *arg);
    void cmdSetCapacity(const char *arg);
    void cmdSetSOC(const char *arg);
    void cmdSaveSettings(void);
    void cmdResetSettings(void);
    void cmdRenumber(void);
    void cmdStatus(void);
};

#endif /* __cplusplus */
#endif /* SERIALCONSOLE_H */
