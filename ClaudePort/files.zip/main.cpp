/*
 * main.cpp - TeslaBMSV2 main application
 * STM32F103C8T6 (Blue Pill) port using libopencm3 + libopeninv
 *
 * This file replaces TeslaBMSV2.ino (setup() + loop() → main())
 *
 * Original Teensy 3.2 dependencies replaced:
 *   ADC.h (pedvide)   → libopencm3 ADC (adc_read_single())
 *   FlexCAN.h         → libopencm3 CAN (bxCAN on PB8/PB9)
 *   Filters.h         → simple IIR low-pass filter (inline)
 *   EEPROM.h          → Flash-based EEPROM emulation in BMSModuleManager
 *   IntervalTimer     → SysTick + counter variables
 *   millis()          → system_ms volatile counter
 *
 * Blue Pill pin mapping:
 *   PA0  - ADC current sensor input (ADC_IN0)
 *   PA2  - USART2 TX → BMS module bus
 *   PA3  - USART2 RX ← BMS module bus
 *   PA9  - USART1 TX → debug serial console
 *   PA10 - USART1 RX ← debug serial console
 *   PB0  - CHARGE_ENABLE output
 *   PB1  - DISCHARGE_ENABLE output
 *   PB8  - CAN1 RX
 *   PB9  - CAN1 TX
 *   PC13 - Onboard LED (active LOW)
 */

#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

#include <libopencm3/stm32/rcc.h>
#include <libopencm3/stm32/gpio.h>
#include <libopencm3/stm32/usart.h>
#include <libopencm3/stm32/adc.h>
#include <libopencm3/stm32/can.h>
#include <libopencm3/stm32/flash.h>
#include <libopencm3/cm3/systick.h>
#include <libopencm3/cm3/nvic.h>

#include "config.h"
#include "Logger.h"
#include "BMSModule.h"
#include "BMSModuleManager.h"
#include "SerialConsole.h"

/* -----------------------------------------------------------------------
 * Global objects
 * ----------------------------------------------------------------------- */
static BMSModuleManager bms;
static SerialConsole    console(bms);

/* -----------------------------------------------------------------------
 * Millisecond tick counter (incremented by SysTick ISR)
 * Replaces: millis() on Arduino/Teensy
 * ----------------------------------------------------------------------- */
volatile uint32_t system_ms = 0;

extern "C" void sys_tick_handler(void)
{
    system_ms++;
}

/* -----------------------------------------------------------------------
 * Simple IIR low-pass filter for current reading
 * Replaces: Filters.h FilterOnePole from Teensy
 *
 * y[n] = alpha * x[n] + (1 - alpha) * y[n-1]
 * alpha = 1/8 → ~8 sample moving average
 * ----------------------------------------------------------------------- */
static float iir_filter(float *state, float input, float alpha)
{
    *state = alpha * input + (1.0f - alpha) * (*state);
    return *state;
}

/* -----------------------------------------------------------------------
 * Clock setup: 72 MHz using 8 MHz HSE crystal (Blue Pill)
 * Replaces: F_CPU / Teensy clock configuration
 * ----------------------------------------------------------------------- */
static void clock_setup(void)
{
    rcc_clock_setup_in_hse_8mhz_out_72mhz();
}

/* -----------------------------------------------------------------------
 * SysTick setup: 1 ms tick at 72 MHz
 * ----------------------------------------------------------------------- */
static void systick_setup(void)
{
    /* 72 MHz / 1000 = 72000 ticks per millisecond */
    systick_set_reload(72000 - 1);
    systick_set_clocksource(STK_CSR_CLKSOURCE_AHB);
    systick_counter_enable();
    systick_interrupt_enable();
}

/* -----------------------------------------------------------------------
 * GPIO setup
 * ----------------------------------------------------------------------- */
static void gpio_setup(void)
{
    rcc_periph_clock_enable(RCC_GPIOA);
    rcc_periph_clock_enable(RCC_GPIOB);
    rcc_periph_clock_enable(RCC_GPIOC);
    rcc_periph_clock_enable(RCC_AFIO);

    /* LED (PC13, active LOW) */
    gpio_set_mode(GPIO_LED_PORT, GPIO_MODE_OUTPUT_2_MHZ,
                  GPIO_CNF_OUTPUT_PUSHPULL, GPIO_LED_PIN);
    gpio_set(GPIO_LED_PORT, GPIO_LED_PIN);   /* LED off */

    /* CHARGE_ENABLE (PB0) */
    gpio_set_mode(GPIO_CHARGE_PORT, GPIO_MODE_OUTPUT_2_MHZ,
                  GPIO_CNF_OUTPUT_PUSHPULL, GPIO_CHARGE_PIN);
    gpio_clear(GPIO_CHARGE_PORT, GPIO_CHARGE_PIN);  /* off */

    /* DISCHARGE_ENABLE (PB1) */
    gpio_set_mode(GPIO_DISCHARGE_PORT, GPIO_MODE_OUTPUT_2_MHZ,
                  GPIO_CNF_OUTPUT_PUSHPULL, GPIO_DISCHARGE_PIN);
    gpio_clear(GPIO_DISCHARGE_PORT, GPIO_DISCHARGE_PIN); /* off */
}

/* -----------------------------------------------------------------------
 * ADC setup for current sensor on PA0 (ADC_IN0)
 * Replaces: Teensy ADC library (adc->adc0->startContinuous())
 * ----------------------------------------------------------------------- */
static void adc_setup(void)
{
    rcc_periph_clock_enable(RCC_ADC1);

    /* PA0 as analog input */
    gpio_set_mode(GPIOA, GPIO_MODE_INPUT, GPIO_CNF_INPUT_ANALOG, GPIO0);

    adc_power_off(ADC1);
    adc_disable_scan_mode(ADC1);
    adc_set_single_conversion_mode(ADC1);
    adc_disable_external_trigger_regular(ADC1);
    adc_set_right_aligned(ADC1);
    adc_set_sample_time(ADC1, ADC_CHANNEL0, ADC_SMPR_SMP_239DOT5CYC);

    adc_power_on(ADC1);

    /* Calibration */
    adc_reset_calibration(ADC1);
    adc_calibrate(ADC1);
}

/* -----------------------------------------------------------------------
 * Read ADC channel 0 (current sensor)
 * Returns: millivolts (0..3300)
 * Replaces: adc->adc0->analogReadContinuous() on Teensy
 * ----------------------------------------------------------------------- */
static uint16_t adc_read_mv(void)
{
    uint8_t ch = ADC_CURRENT_CHANNEL;
    adc_set_regular_sequence(ADC1, 1, &ch);
    adc_start_conversion_direct(ADC1);
    while (!adc_eoc(ADC1));
    uint16_t raw = adc_read_regular(ADC1);   /* 12-bit: 0..4095 */
    return (uint16_t)((uint32_t)raw * 3300 / 4095);
}

/* -----------------------------------------------------------------------
 * CAN bus setup (bxCAN, 500 kbps)
 * Replaces: FlexCAN (Teensy) → libopencm3 CAN
 *
 * Remap CAN to PB8/PB9 (required on Blue Pill; default is PA11/PA12
 * which conflicts with USB).
 * ----------------------------------------------------------------------- */
static void can_setup(void)
{
    rcc_periph_clock_enable(RCC_CAN1);
    rcc_periph_clock_enable(RCC_GPIOB);
    rcc_periph_clock_enable(RCC_AFIO);

    /* Remap CAN1 to PB8(RX)/PB9(TX) */
    AFIO_MAPR |= AFIO_MAPR_CAN1_REMAP_PORTB;

    gpio_set_mode(GPIOB, GPIO_MODE_INPUT,
                  GPIO_CNF_INPUT_FLOAT, GPIO8);              /* CAN RX */
    gpio_set_mode(GPIOB, GPIO_MODE_OUTPUT_50_MHZ,
                  GPIO_CNF_OUTPUT_ALTFN_PUSHPULL, GPIO9);    /* CAN TX */

    /* Initialise bxCAN at 500 kbps
     * APB1 = 36 MHz; prescaler=4, ts1=9, ts2=8 → 500 kbps */
    int err = can_init(
        CAN1,
        false,   /* TTCM */
        true,    /* ABOM - auto bus-off management */
        false,   /* AWUM */
        false,   /* NART */
        false,   /* RFLM */
        false,   /* TXFP */
        CAN_BTR_SJW_1TQ,
        CAN_BTR_TS1_9TQ,
        CAN_BTR_TS2_8TQ,
        4,       /* prescaler */
        false,   /* loopback */
        false    /* silent */
    );

    if (err != 0) {
        LOG_ERROR("CAN init failed: %d", err);
    }

    /* Accept all frames (no filter) */
    can_filter_id_mask_32bit_init(
        0,       /* filter bank 0 */
        0,       /* id */
        0,       /* mask (0 = accept all) */
        0,       /* FIFO 0 */
        true     /* enable */
    );
}

/* -----------------------------------------------------------------------
 * Send Victron/SMA CAN heartbeat frames
 * Replaces: CANIO / Victron CAN send routines in original TeslaBMSV2.ino
 *
 * Frame format per Victron DVCC / SMA CAN BMS protocol
 * ----------------------------------------------------------------------- */
static void can_send_bms_data(void)
{
    uint8_t data[8];
    bool req_tx;
    uint32_t err;

    float packV   = bms.getPackVoltage();
    float soc     = bms.getSOC();
    float highT   = bms.getHighTemperature();
    float current = bms.getCurrent();

    /* 0x351 – Charge voltage / current limits */
    uint16_t cv_limit  = (uint16_t)(bms.settings.overVoltage * bms.settings.numModules *
                                    MAX_CELLS_PER_MODULE / 10);
    uint16_t cc_limit  = (uint16_t)(bms.settings.packCapacityAh * 10); /* 0.1A units */
    uint16_t dc_limit  = cc_limit;
    data[0] = (uint8_t)(cv_limit & 0xFF);
    data[1] = (uint8_t)(cv_limit >> 8);
    data[2] = (uint8_t)(cc_limit & 0xFF);
    data[3] = (uint8_t)(cc_limit >> 8);
    data[4] = (uint8_t)(dc_limit & 0xFF);
    data[5] = (uint8_t)(dc_limit >> 8);
    data[6] = 0; data[7] = 0;
    can_transmit(CAN1, CAN_ID_BMS_SOC, false, false, 8, data);

    /* 0x355 – SOC / SOH */
    uint16_t soc_int = (uint16_t)soc;
    data[0] = (uint8_t)(soc_int & 0xFF);
    data[1] = (uint8_t)(soc_int >> 8);
    data[2] = 0x64; data[3] = 0x00;  /* SOH = 100% */
    data[4] = 0; data[5] = 0; data[6] = 0; data[7] = 0;
    can_transmit(CAN1, CAN_ID_BMS_VOLT, false, false, 8, data);

    /* 0x356 – Voltage / current / temperature */
    int16_t volt_can = (int16_t)(packV * 100.0f);
    int16_t curr_can = (int16_t)(current * 10.0f);
    int16_t temp_can = (int16_t)(highT * 10.0f);
    data[0] = (uint8_t)(volt_can & 0xFF);
    data[1] = (uint8_t)(volt_can >> 8);
    data[2] = (uint8_t)(curr_can & 0xFF);
    data[3] = (uint8_t)(curr_can >> 8);
    data[4] = (uint8_t)(temp_can & 0xFF);
    data[5] = (uint8_t)(temp_can >> 8);
    data[6] = 0; data[7] = 0;
    can_transmit(CAN1, CAN_ID_BMS_TEMP, false, false, 8, data);

    /* 0x35A – Alarm / warning flags */
    uint8_t alarms  = 0;
    uint8_t warnings = 0;
    if (bms.hasOverVoltage())  { alarms  |= (1 << 2); }
    if (bms.hasUnderVoltage()) { alarms  |= (1 << 4); }
    if (bms.hasOverTemp())     { alarms  |= (1 << 6); }
    if (bms.hasOverVoltage())  { warnings |= (1 << 2); }
    if (bms.hasUnderVoltage()) { warnings |= (1 << 4); }
    data[0] = alarms;
    data[1] = warnings;
    data[2] = 0; data[3] = 0; data[4] = 0;
    data[5] = 0; data[6] = 0; data[7] = 0;
    can_transmit(CAN1, CAN_ID_BMS_ALARM, false, false, 8, data);

    /* 0x35C – BMS status flags */
    data[0] = 0xC0;   /* charge + discharge enabled */
    data[1] = 0x00;
    memset(&data[2], 0, 6);
    can_transmit(CAN1, CAN_ID_BMS_STATUS, false, false, 8, data);
}

/* -----------------------------------------------------------------------
 * SOC update using coulomb counting
 * Replaces: ampsecond / SOC tracking in original loop()
 * ----------------------------------------------------------------------- */
static void update_soc(float current_a, float dt_s)
{
    float packCapAs = (float)bms.settings.packCapacityAh *
                      (float)bms.settings.parallelStrings * 3600.0f;

    bms.addAmpseconds(current_a * dt_s);

    float as = bms.getAmpseconds();
    float soc = (as / packCapAs) * 100.0f;

    /* Clamp */
    if (soc > 100.0f) soc = 100.0f;
    if (soc < 0.0f)   soc = 0.0f;

    bms.setSOC(soc);
}

/* -----------------------------------------------------------------------
 * main() — replaces setup() + loop()
 * ----------------------------------------------------------------------- */
int main(void)
{
    clock_setup();
    systick_setup();
    gpio_setup();
    logger_init();
    adc_setup();
    can_setup();

    bms.init();
    console.init();

    LOG_INFO("System ready. %d modules found.", bms.getNumModules());

    /* Timing variables (replaces Arduino millis() comparisons) */
    uint32_t last_loop_ms    = system_ms;
    uint32_t last_balance_ms = system_ms;
    uint32_t last_can_ms     = system_ms;
    uint32_t last_led_ms     = system_ms;

    /* Current filter state */
    float current_filtered = 0.0f;
    const float IIR_ALPHA  = 0.125f;  /* ~8-sample smoothing */

    bool charge_enabled    = false;
    bool discharge_enabled = false;

    /* ---- Main loop ---- */
    while (1) {
        uint32_t now = system_ms;

        /* ---- 100 ms tasks: read BMS modules, update current ---- */
        if ((now - last_loop_ms) >= LOOP_PERIOD_MS) {
            float dt_s = (float)(now - last_loop_ms) / 1000.0f;
            last_loop_ms = now;

            /* Read BMS module data */
            bms.updateVoltages();
            bms.updateTemperatures();
            bms.updateBalanceStatus();

            /* Read current sensor (ADC)
             * Replaces: adc->adc0->analogReadContinuous() on Teensy
             *
             * Current (A) = (Vmeasured_mV - offset_mV) / gain_mV_per_A
             */
            uint16_t adc_mv = adc_read_mv();
            float raw_current =
                (float)((int32_t)adc_mv - (int32_t)bms.settings.currentOffset) /
                (float)bms.settings.currentGainLow;

            /* Apply deadband */
            float deadband_a = (float)bms.settings.currentDeadband /
                               (float)bms.settings.currentGainLow;
            if (raw_current > -deadband_a && raw_current < deadband_a) {
                raw_current = 0.0f;
            }

            current_filtered = iir_filter(&current_filtered, raw_current, IIR_ALPHA);
            bms.setCurrent(current_filtered);

            /* Coulomb counting */
            update_soc(current_filtered, dt_s);

            /* Contactor control */
            bool fault = bms.hasFault();
            charge_enabled    = !fault;
            discharge_enabled = !fault;

            if (charge_enabled) {
                gpio_set(GPIO_CHARGE_PORT, GPIO_CHARGE_PIN);
            } else {
                gpio_clear(GPIO_CHARGE_PORT, GPIO_CHARGE_PIN);
            }

            if (discharge_enabled) {
                gpio_set(GPIO_DISCHARGE_PORT, GPIO_DISCHARGE_PIN);
            } else {
                gpio_clear(GPIO_DISCHARGE_PORT, GPIO_DISCHARGE_PIN);
            }

            LOG_DEBUG("Pack: %.2fV  SOC: %.1f%%  I: %.2fA  HI: %.4fV  LO: %.4fV",
                      (double)bms.getPackVoltage(),
                      (double)bms.getSOC(),
                      (double)bms.getCurrent(),
                      (double)bms.getHighCellVolt(),
                      (double)bms.getLowCellVolt());
        }

        /* ---- 1000 ms tasks: balancing + CAN ---- */
        if ((now - last_balance_ms) >= BALANCE_CHECK_MS) {
            last_balance_ms = now;
            bms.balanceCells(true);
        }

        if ((now - last_can_ms) >= CAN_TX_PERIOD_MS) {
            last_can_ms = now;
            can_send_bms_data();
        }

        /* ---- LED heartbeat: 500 ms blink ---- */
        if ((now - last_led_ms) >= 500) {
            last_led_ms = now;
            gpio_toggle(GPIO_LED_PORT, GPIO_LED_PIN);
        }

        /* ---- Serial console (non-blocking, polls USART1 RX) ---- */
        console.tick();
    }

    return 0;
}
