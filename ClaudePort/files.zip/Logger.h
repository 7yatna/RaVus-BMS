#pragma once
/*
 * Logger.h - Debug logging over USART1 (PA9/PA10 @ 115200 baud)
 * STM32F103 port of TeslaBMSV2 Logger using libopencm3
 */

#ifndef LOGGER_H
#define LOGGER_H

#include <stdint.h>
#include <libopencm3/stm32/usart.h>
#include "config.h"

/* Log levels */
typedef enum {
    LOG_ERROR   = 0,
    LOG_WARN    = 1,
    LOG_INFO    = 2,
    LOG_DEBUG   = 3
} LogLevel;

#ifdef __cplusplus
extern "C" {
#endif

void     logger_init(void);
void     logger_set_level(LogLevel level);
LogLevel logger_get_level(void);

/* Printf-style logging */
void     logger_log(LogLevel level, const char *fmt, ...);

/* Raw character / string output on debug USART */
void     logger_putchar(char c);
void     logger_puts(const char *s);

/* Convenience macros */
#define LOG_ERROR(fmt, ...)  logger_log(LOG_ERROR, fmt, ##__VA_ARGS__)
#define LOG_WARN(fmt, ...)   logger_log(LOG_WARN,  fmt, ##__VA_ARGS__)
#define LOG_INFO(fmt, ...)   logger_log(LOG_INFO,  fmt, ##__VA_ARGS__)
#define LOG_DEBUG(fmt, ...)  logger_log(LOG_DEBUG,  fmt, ##__VA_ARGS__)

#ifdef __cplusplus
}
#endif

#endif /* LOGGER_H */
