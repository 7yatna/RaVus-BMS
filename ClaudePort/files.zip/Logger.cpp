/*
 * Logger.cpp - Debug logging over USART1
 * STM32F103 (Blue Pill) port of TeslaBMSV2 Logger
 *
 * Maps to: Arduino Serial (debug port)  →  USART1 PA9/PA10 @ 115200
 */

#include "Logger.h"
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <libopencm3/stm32/rcc.h>
#include <libopencm3/stm32/gpio.h>
#include <libopencm3/stm32/usart.h>

static LogLevel current_level = LOG_INFO;

/* -----------------------------------------------------------------------
 * logger_init()
 * Initialises USART1 for debug output (replaces Arduino Serial.begin())
 * PA9  = TX (AF push-pull)
 * PA10 = RX (input pull-up)
 * ----------------------------------------------------------------------- */
void logger_init(void)
{
    /* Enable clocks */
    rcc_periph_clock_enable(RCC_GPIOA);
    rcc_periph_clock_enable(RCC_USART1);

    /* PA9  → TX (alternate function push-pull) */
    gpio_set_mode(GPIOA, GPIO_MODE_OUTPUT_50_MHZ,
                  GPIO_CNF_OUTPUT_ALTFN_PUSHPULL, GPIO9);

    /* PA10 → RX (input floating / pull-up managed by USART) */
    gpio_set_mode(GPIOA, GPIO_MODE_INPUT,
                  GPIO_CNF_INPUT_FLOAT, GPIO10);

    /* Configure USART1 */
    usart_set_baudrate(USART1, USART_DEBUG_BAUD);
    usart_set_databits(USART1, 8);
    usart_set_stopbits(USART1, USART_STOPBITS_1);
    usart_set_parity(USART1, USART_PARITY_NONE);
    usart_set_mode(USART1, USART_MODE_TX_RX);
    usart_set_flow_control(USART1, USART_FLOWCONTROL_NONE);
    usart_enable(USART1);
}

void logger_set_level(LogLevel level)
{
    current_level = level;
}

LogLevel logger_get_level(void)
{
    return current_level;
}

/* -----------------------------------------------------------------------
 * Blocking single-character output (replaces Serial.write())
 * ----------------------------------------------------------------------- */
void logger_putchar(char c)
{
    usart_send_blocking(USART1, (uint16_t)c);
}

/* -----------------------------------------------------------------------
 * Blocking string output (replaces Serial.print(str))
 * ----------------------------------------------------------------------- */
void logger_puts(const char *s)
{
    while (*s) {
        logger_putchar(*s++);
    }
}

/* -----------------------------------------------------------------------
 * Printf-style logging
 * (replaces Serial.print(val) / Serial.println(val) etc.)
 * ----------------------------------------------------------------------- */
void logger_log(LogLevel level, const char *fmt, ...)
{
    if (level > current_level) return;

    /* Level prefix */
    switch (level) {
        case LOG_ERROR: logger_puts("[ERR] ");  break;
        case LOG_WARN:  logger_puts("[WRN] ");  break;
        case LOG_INFO:  logger_puts("[INF] ");  break;
        case LOG_DEBUG: logger_puts("[DBG] ");  break;
    }

    char buf[256];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);

    logger_puts(buf);
    logger_puts("\r\n");
}
