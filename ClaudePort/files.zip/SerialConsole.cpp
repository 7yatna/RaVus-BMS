/*
 * SerialConsole.cpp - Interactive serial console over USART1
 * STM32F103 port of TeslaBMSV2
 *
 * The original used Arduino Serial.print() and Serial.read().
 * Here we use libopencm3 USART1 via the Logger module for output
 * and handle input byte-by-byte (no blocking readLine).
 *
 * Command format matches the original TeslaBMSV2 console:
 *   <number><value>   e.g. "14200" = set command 1, value 4200
 */

#include "SerialConsole.h"
#include "Logger.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <libopencm3/stm32/usart.h>

/* -----------------------------------------------------------------------
 * Command numbers (match original TeslaBMSV2 SerialConsole.cpp)
 * ----------------------------------------------------------------------- */
#define CMD_OVER_VOLT    1    /* over-voltage threshold (mV)  */
#define CMD_UNDER_VOLT   2    /* under-voltage threshold (mV) */
#define CMD_BAL_VOLT     3    /* balance start voltage (mV)   */
#define CMD_BAL_DIFF     4    /* balance delta (mV)           */
#define CMD_OVER_TEMP    5    /* over-temperature limit (°C)  */
#define CMD_CAPACITY     6    /* pack capacity (Ah)           */
#define CMD_SET_SOC      7    /* manually set SOC (0..100)    */
#define CMD_SAVE         8    /* save settings to Flash       */
#define CMD_RESET        9    /* reset settings to defaults   */
#define CMD_RENUMBER     10   /* re-enumerate BMS modules     */
#define CMD_STATUS       11   /* print full status            */
#define CMD_LOGLEVEL     12   /* set log level (0..3)         */

/* -----------------------------------------------------------------------
 * Constructor
 * ----------------------------------------------------------------------- */
SerialConsole::SerialConsole(BMSModuleManager &bms_ref)
    : bms(bms_ref), rxIdx(0), commandReady(false)
{
    memset(rxBuf, 0, sizeof(rxBuf));
}

/* -----------------------------------------------------------------------
 * init() — print welcome banner
 * ----------------------------------------------------------------------- */
void SerialConsole::init(void)
{
    logger_puts("\r\n");
    logger_puts("========================================\r\n");
    logger_puts("  TeslaBMSV2 - STM32F103 Blue Pill port \r\n");
    logger_puts("  libopencm3 build                      \r\n");
    logger_puts("========================================\r\n");
    printHelp();
}

/* -----------------------------------------------------------------------
 * handleByte() — called from USART1 RX ISR or main loop polling
 * Accumulates characters until CR/LF then sets commandReady flag.
 * Replaces: Arduino Serial.read() character accumulation logic
 * ----------------------------------------------------------------------- */
void SerialConsole::handleByte(uint8_t c)
{
    if (c == '\r' || c == '\n') {
        if (rxIdx > 0) {
            rxBuf[rxIdx] = '\0';
            commandReady = true;
        }
        return;
    }

    /* Backspace */
    if (c == 0x08 || c == 0x7F) {
        if (rxIdx > 0) {
            rxIdx--;
            logger_puts("\b \b");  /* erase character on terminal */
        }
        return;
    }

    /* Echo character back */
    logger_putchar((char)c);

    if (rxIdx < CONSOLE_BUF_LEN - 1) {
        rxBuf[rxIdx++] = (char)c;
    }
}

/* -----------------------------------------------------------------------
 * tick() — called in main loop to process complete commands
 * ----------------------------------------------------------------------- */
void SerialConsole::tick(void)
{
    /* Poll USART1 RX (alternative to ISR-driven approach) */
    while (USART_SR(USART1) & USART_SR_RXNE) {
        uint8_t c = (uint8_t)usart_recv(USART1);
        handleByte(c);
    }

    if (commandReady) {
        commandReady = false;
        processCommand();
        rxIdx = 0;
        memset(rxBuf, 0, sizeof(rxBuf));
        logger_puts("\r\n> ");
    }
}

/* -----------------------------------------------------------------------
 * processCommand() — parse and dispatch console commands
 * Format: first digit(s) = command number, rest = value
 * e.g. "14200" → command 1, value 4200
 * ----------------------------------------------------------------------- */
void SerialConsole::processCommand(void)
{
    if (rxIdx == 0) return;

    /* Extract command number (leading digits) */
    char *p = rxBuf;
    char numBuf[8] = {0};
    uint8_t ni = 0;
    while (*p >= '0' && *p <= '9' && ni < 6) {
        numBuf[ni++] = *p++;
    }
    if (ni == 0) {
        logger_puts("Unknown command. Type 11 for help.\r\n");
        return;
    }

    int cmd = atoi(numBuf);
    const char *arg = p;  /* remainder of buffer = argument */

    switch (cmd) {
        case CMD_OVER_VOLT:   cmdSetOverVolt(arg);   break;
        case CMD_UNDER_VOLT:  cmdSetUnderVolt(arg);  break;
        case CMD_BAL_VOLT:    cmdSetBalVolt(arg);    break;
        case CMD_BAL_DIFF:    cmdSetBalDiff(arg);    break;
        case CMD_OVER_TEMP:   cmdSetOverTemp(arg);   break;
        case CMD_CAPACITY:    cmdSetCapacity(arg);   break;
        case CMD_SET_SOC:     cmdSetSOC(arg);        break;
        case CMD_SAVE:        cmdSaveSettings();     break;
        case CMD_RESET:       cmdResetSettings();    break;
        case CMD_RENUMBER:    cmdRenumber();         break;
        case CMD_STATUS:      cmdStatus();           break;
        case CMD_LOGLEVEL:
            logger_set_level((LogLevel)atoi(arg));
            logger_puts("Log level set.\r\n");
            break;
        default:
            logger_puts("Unknown command. Type 11 for help.\r\n");
    }
}

/* -----------------------------------------------------------------------
 * printHelp()
 * ----------------------------------------------------------------------- */
void SerialConsole::printHelp(void)
{
    logger_puts("\r\nCommands (format: <number><value>):\r\n");
    logger_puts("  1<mV>  - Set over-voltage threshold (e.g. 14200 = 4200 mV)\r\n");
    logger_puts("  2<mV>  - Set under-voltage threshold\r\n");
    logger_puts("  3<mV>  - Set balance start voltage\r\n");
    logger_puts("  4<mV>  - Set balance delta\r\n");
    logger_puts("  5<°C>  - Set over-temperature limit\r\n");
    logger_puts("  6<Ah>  - Set pack capacity\r\n");
    logger_puts("  7<%>   - Set SOC manually\r\n");
    logger_puts("  8      - Save settings to Flash\r\n");
    logger_puts("  9      - Reset settings to defaults\r\n");
    logger_puts("  10     - Re-enumerate BMS modules\r\n");
    logger_puts("  11     - Print full status\r\n");
    logger_puts("  12<0-3>- Set log level (0=ERR, 3=DBG)\r\n\r\n");
}

/* -----------------------------------------------------------------------
 * printStatus() — full pack status dump
 * Replaces: various Serial.print() calls in original loop()
 * ----------------------------------------------------------------------- */
void SerialConsole::printStatus(void)
{
    char buf[128];

    logger_puts("\r\n===== BMS STATUS =====\r\n");

    snprintf(buf, sizeof(buf), "Modules:       %d\r\n", bms.getNumModules());
    logger_puts(buf);

    snprintf(buf, sizeof(buf), "Pack voltage:  %.3f V\r\n", (double)bms.getPackVoltage());
    logger_puts(buf);

    snprintf(buf, sizeof(buf), "High cell:     %.4f V\r\n", (double)bms.getHighCellVolt());
    logger_puts(buf);

    snprintf(buf, sizeof(buf), "Low cell:      %.4f V\r\n", (double)bms.getLowCellVolt());
    logger_puts(buf);

    snprintf(buf, sizeof(buf), "Cell delta:    %.1f mV\r\n",
             (double)(bms.getCellDelta() * 1000.0f));
    logger_puts(buf);

    snprintf(buf, sizeof(buf), "Avg cell:      %.4f V\r\n", (double)bms.getAvgCellVolt());
    logger_puts(buf);

    snprintf(buf, sizeof(buf), "High temp:     %.1f C\r\n", (double)bms.getHighTemperature());
    logger_puts(buf);

    snprintf(buf, sizeof(buf), "Low temp:      %.1f C\r\n", (double)bms.getLowTemperature());
    logger_puts(buf);

    snprintf(buf, sizeof(buf), "Current:       %.2f A\r\n", (double)bms.getCurrent());
    logger_puts(buf);

    snprintf(buf, sizeof(buf), "SOC:           %.1f %%\r\n", (double)bms.getSOC());
    logger_puts(buf);

    /* Fault flags */
    logger_puts("Faults:        ");
    bool any = false;
    if (bms.hasOverVoltage())  { logger_puts("OV ");  any = true; }
    if (bms.hasUnderVoltage()) { logger_puts("UV ");  any = true; }
    if (bms.hasOverTemp())     { logger_puts("OT ");  any = true; }
    if (bms.hasUnderTemp())    { logger_puts("UT ");  any = true; }
    if (!any)                   logger_puts("None");
    logger_puts("\r\n");

    /* Per-module detail */
    for (uint8_t m = 0; m < bms.getNumModules(); m++) {
        BMSModule &mod = bms.getModule(m);
        if (!mod.isExisting()) continue;

        snprintf(buf, sizeof(buf), "\r\nModule %d (addr 0x%02X)%s:\r\n",
                 m, mod.getAddress(), mod.isFaulty() ? " [FAULT]" : "");
        logger_puts(buf);

        for (uint8_t c = 0; c < MAX_CELLS_PER_MODULE; c++) {
            snprintf(buf, sizeof(buf), "  Cell %d: %.4f V%s\r\n",
                     c + 1, (double)mod.getCellVoltage(c),
                     (mod.balanceStatus & (1 << c)) ? " [BAL]" : "");
            logger_puts(buf);
        }

        snprintf(buf, sizeof(buf), "  Temp1: %.1f C   Temp2: %.1f C\r\n",
                 (double)mod.getTemperature(0), (double)mod.getTemperature(1));
        logger_puts(buf);
    }

    logger_puts("======================\r\n");
}

/* -----------------------------------------------------------------------
 * Individual command handlers
 * ----------------------------------------------------------------------- */
void SerialConsole::cmdSetOverVolt(const char *arg)
{
    uint16_t v = (uint16_t)atoi(arg);
    if (v > 2000 && v < 5000) {
        bms.settings.overVoltage = v;
        char buf[64];
        snprintf(buf, sizeof(buf), "Over-voltage set to %d mV\r\n", v);
        logger_puts(buf);
    } else {
        logger_puts("Invalid value (2000..5000 mV)\r\n");
    }
}

void SerialConsole::cmdSetUnderVolt(const char *arg)
{
    uint16_t v = (uint16_t)atoi(arg);
    if (v > 1000 && v < 4000) {
        bms.settings.underVoltage = v;
        char buf[64];
        snprintf(buf, sizeof(buf), "Under-voltage set to %d mV\r\n", v);
        logger_puts(buf);
    } else {
        logger_puts("Invalid value (1000..4000 mV)\r\n");
    }
}

void SerialConsole::cmdSetBalVolt(const char *arg)
{
    uint16_t v = (uint16_t)atoi(arg);
    if (v > 2000 && v < 5000) {
        bms.settings.balanceVoltage = v;
        char buf[64];
        snprintf(buf, sizeof(buf), "Balance voltage set to %d mV\r\n", v);
        logger_puts(buf);
    } else {
        logger_puts("Invalid value (2000..5000 mV)\r\n");
    }
}

void SerialConsole::cmdSetBalDiff(const char *arg)
{
    uint16_t v = (uint16_t)atoi(arg);
    if (v >= 5 && v <= 500) {
        bms.settings.balanceDiff = v;
        char buf[64];
        snprintf(buf, sizeof(buf), "Balance delta set to %d mV\r\n", v);
        logger_puts(buf);
    } else {
        logger_puts("Invalid value (5..500 mV)\r\n");
    }
}

void SerialConsole::cmdSetOverTemp(const char *arg)
{
    int16_t t = (int16_t)atoi(arg);
    if (t > 0 && t <= 90) {
        bms.settings.overTemp = t;
        char buf[64];
        snprintf(buf, sizeof(buf), "Over-temperature set to %d C\r\n", t);
        logger_puts(buf);
    } else {
        logger_puts("Invalid value (1..90 C)\r\n");
    }
}

void SerialConsole::cmdSetCapacity(const char *arg)
{
    uint16_t cap = (uint16_t)atoi(arg);
    if (cap > 0 && cap < 1000) {
        bms.settings.packCapacityAh = cap;
        char buf[64];
        snprintf(buf, sizeof(buf), "Capacity set to %d Ah\r\n", cap);
        logger_puts(buf);
    } else {
        logger_puts("Invalid value (1..999 Ah)\r\n");
    }
}

void SerialConsole::cmdSetSOC(const char *arg)
{
    int soc = atoi(arg);
    if (soc >= 0 && soc <= 100) {
        bms.setSOC((float)soc);
        /* Recalculate amp-seconds to match new SOC */
        float as = ((float)soc * (float)bms.settings.packCapacityAh * 3600.0f) / 100.0f;
        bms.setSOC((float)soc);
        char buf[64];
        snprintf(buf, sizeof(buf), "SOC set to %d%%\r\n", soc);
        logger_puts(buf);
    } else {
        logger_puts("Invalid value (0..100)\r\n");
    }
}

void SerialConsole::cmdSaveSettings(void)
{
    bms.saveSettings();
    logger_puts("Settings saved to Flash.\r\n");
}

void SerialConsole::cmdResetSettings(void)
{
    bms.resetSettings();
    logger_puts("Settings reset to defaults.\r\n");
}

void SerialConsole::cmdRenumber(void)
{
    logger_puts("Re-enumerating modules...\r\n");
    bms.renumberModules();
}

void SerialConsole::cmdStatus(void)
{
    printStatus();
}
