/*
 * BMSModule.cpp - Tesla Model S BMS module driver
 * STM32F103 port of TeslaBMSV2
 *
 * Voltage conversion:  raw 14-bit ADC → volts
 *   V = (raw * 5.0) / 16383.0   (for cell voltage registers)
 *
 * Temperature conversion: raw 14-bit ADC → °C (NTC thermistor)
 *   Uses the original TeslaBMS lookup / formula
 */

#include "BMSModule.h"
#include <string.h>
#include <math.h>

/* -----------------------------------------------------------------------
 * Raw ADC → cell voltage (V)
 * The Tesla BMS module returns 14-bit values; full scale = 5 V
 * ----------------------------------------------------------------------- */
float BMSModule::rawToVoltage(uint16_t raw)
{
    return ((float)raw * 5.0f) / 16383.0f;
}

/* -----------------------------------------------------------------------
 * Raw ADC → temperature (°C)
 * Uses simplified Steinhart-Hart for the onboard NTC thermistor.
 * R25 = 10 kΩ, B = 3984 K (Tesla BMS module thermistor values)
 * ----------------------------------------------------------------------- */
float BMSModule::rawToTemp(uint16_t raw)
{
    if (raw == 0) return -273.0f; /* guard against divide by zero */

    /* Convert ADC reading to resistance (Vref = 3.3 V, series R = 10 kΩ) */
    float Vout  = ((float)raw / 16383.0f) * 3.3f;
    float R_ntc = 10000.0f * Vout / (3.3f - Vout);

    /* Steinhart-Hart simplified (B-parameter equation) */
    const float R25  = 10000.0f;  /* nominal resistance at 25°C */
    const float B    = 3984.0f;   /* B constant                 */
    const float T25  = 298.15f;   /* 25°C in Kelvin             */

    float tempK = 1.0f / ((1.0f / T25) + (1.0f / B) * logf(R_ntc / R25));
    return tempK - 273.15f;
}

/* -----------------------------------------------------------------------
 * BMSModule constructor
 * ----------------------------------------------------------------------- */
BMSModule::BMSModule()
    : address(0), exists(false), fault(false),
      alertStatus(0), faultStatus(0), balanceStatus(0), balancing(false)
{
    memset(cellVoltageRaw, 0, sizeof(cellVoltageRaw));
    memset(temperatureRaw, 0, sizeof(temperatureRaw));
}

/* -----------------------------------------------------------------------
 * Cell voltage accessors
 * ----------------------------------------------------------------------- */
float BMSModule::getCellVoltage(uint8_t cell) const
{
    if (cell >= MAX_CELLS_PER_MODULE) return 0.0f;
    return rawToVoltage(cellVoltageRaw[cell]);
}

float BMSModule::getModuleVoltage(void) const
{
    float total = 0.0f;
    for (uint8_t i = 0; i < MAX_CELLS_PER_MODULE; i++) {
        total += getCellVoltage(i);
    }
    return total;
}

float BMSModule::getHighCellVolt(void) const
{
    float high = 0.0f;
    for (uint8_t i = 0; i < MAX_CELLS_PER_MODULE; i++) {
        float v = getCellVoltage(i);
        if (v > high) high = v;
    }
    return high;
}

float BMSModule::getLowCellVolt(void) const
{
    float low = 9999.0f;
    for (uint8_t i = 0; i < MAX_CELLS_PER_MODULE; i++) {
        float v = getCellVoltage(i);
        if (v < low) low = v;
    }
    return (low == 9999.0f) ? 0.0f : low;
}

float BMSModule::getAvgCellVolt(void) const
{
    float sum = 0.0f;
    for (uint8_t i = 0; i < MAX_CELLS_PER_MODULE; i++) {
        sum += getCellVoltage(i);
    }
    return sum / (float)MAX_CELLS_PER_MODULE;
}

/* -----------------------------------------------------------------------
 * Temperature accessors
 * ----------------------------------------------------------------------- */
float BMSModule::getTemperature(uint8_t sensor) const
{
    if (sensor >= 2) return 0.0f;
    return rawToTemp(temperatureRaw[sensor]);
}

float BMSModule::getAvgTemperature(void) const
{
    return (getTemperature(0) + getTemperature(1)) / 2.0f;
}
