#pragma once
/*
 * config.h — TeslaBMSV2 ported to STM32F103C8T6 (Blue Pill)
 * Toolchain: libopencm3
 *
 * Original: https://github.com/Tom-evnut/TeslaBMSV2
 *
 * Pin mapping (Blue Pill STM32F103C8T6):
 *
 *  USART1  PA9=TX  PA10=RX   → debug console (replaces Teensy USB Serial)
 *  USART3  PB10=TX PB11=RX   → Tesla BMS module bus @ 612500 baud
 *                               (replaces Serial3 on Teensy)
 *  CAN1    PB8=RX  PB9=TX    → CAN bus, remapped via AFIO (replaces FlexCAN)
 *  ADC1    PA0=IN0            → current sensor ACUR1 (was A1 on Teensy)
 *  ADC1    PA1=IN1            → current sensor ACUR2 (was A0 on Teensy)
 *
 *  IN1   = PB0  (input, high-active)
 *  IN2   = PB1  (input, high-active)
 *  IN3   = PB3  (input, high-active)
 *  IN4   = PB4  (input, high-active, CP pilot interrupt)
 *
 *  OUT1  = PA8  (output, high-active — discharge contactor)
 *  OUT2  = PB5  (output, high-active — main contactor)
 *  OUT3  = PB6  (output, high-active — charge relay)
 *  OUT4  = PB7  (output, high-active — negative / precharge contactor)
 *  OUT5  = PA6  (PWM — TIM3_CH1)
 *  OUT6  = PA7  (PWM — TIM3_CH2)
 *  OUT7  = PB0  (PWM — TIM3_CH3) *** shared with IN1, remap if needed ***
 *  OUT8  = PB1  (PWM — TIM3_CH4) *** shared with IN2, remap if needed ***
 *
 *  LED   = PC13 (onboard Blue Pill LED, active LOW)
 *
 * NOTE: OUT7/OUT8 share PB0/PB1 with IN1/IN2 in the mapping above.
 *       Adjust to free pins on your actual hardware.
 */

#ifndef CONFIG_H
#define CONFIG_H

#include <stdint.h>
#include <stdbool.h>
#include <libopencm3/stm32/gpio.h>
#include <libopencm3/stm32/usart.h>

/* -----------------------------------------------------------------------
 * Serial port definitions
 * SERIALCONSOLE → USART1 (replaces Arduino "Serial" / Teensy USB)
 * SERIALBMS     → USART3 (replaces Arduino "Serial3" on Teensy)
 * ----------------------------------------------------------------------- */
#define SERIALCONSOLE_USART     USART1
#define SERIALCONSOLE_BAUD      115200
#define SERIALCONSOLE_PORT      GPIOA
#define SERIALCONSOLE_TX_PIN    GPIO9
#define SERIALCONSOLE_RX_PIN    GPIO10

#define SERIALBMS_USART         USART3
#define SERIALBMS_BAUD          612500
#define SERIALBMS_PORT          GPIOB
#define SERIALBMS_TX_PIN        GPIO10
#define SERIALBMS_RX_PIN        GPIO11

/* -----------------------------------------------------------------------
 * GPIO pin definitions
 * ----------------------------------------------------------------------- */
/* Inputs */
#define IN1_PORT    GPIOB
#define IN1_PIN     GPIO0
#define IN2_PORT    GPIOB
#define IN2_PIN     GPIO1
#define IN3_PORT    GPIOB
#define IN3_PIN     GPIO3
#define IN4_PORT    GPIOB
#define IN4_PIN     GPIO4

/* Outputs */
#define OUT1_PORT   GPIOA   /* discharge contactor */
#define OUT1_PIN    GPIO8
#define OUT2_PORT   GPIOB   /* main contactor */
#define OUT2_PIN    GPIO5
#define OUT3_PORT   GPIOB   /* charge relay */
#define OUT3_PIN    GPIO6
#define OUT4_PORT   GPIOB   /* negative / precharge contactor */
#define OUT4_PIN    GPIO7

/* Onboard LED (active LOW) */
#define LED_PORT    GPIOC
#define LED_PIN     GPIO13

/* -----------------------------------------------------------------------
 * BMS module register map (from original config.h — exact values)
 * ----------------------------------------------------------------------- */
#define REG_DEV_STATUS      0
#define REG_GPAI            1
#define REG_VCELL1          3
#define REG_VCELL2          5
#define REG_VCELL3          7
#define REG_VCELL4          9
#define REG_VCELL5          0xB
#define REG_VCELL6          0xD
#define REG_TEMPERATURE1    0xF
#define REG_TEMPERATURE2    0x11
#define REG_ALERT_STATUS    0x20
#define REG_FAULT_STATUS    0x21
#define REG_COV_FAULT       0x22
#define REG_CUV_FAULT       0x23
#define REG_ADC_CTRL        0x30
#define REG_IO_CTRL         0x31
#define REG_BAL_CTRL        0x32
#define REG_BAL_TIME        0x33
#define REG_ADC_CONV        0x34
#define REG_ADDR_CTRL       0x3B

#define MAX_MODULE_ADDR     0x3E

/* -----------------------------------------------------------------------
 * EEPROM (Flash emulation) settings
 * ----------------------------------------------------------------------- */
#define EEPROM_VERSION      0x14    /* bump whenever EEPROMSettings changes */
#define EEPROM_PAGE         0

/* Flash address for settings (last 2 KB page of 64 KB flash) */
#define SETTINGS_FLASH_ADDR     0x0800F800ul

/* -----------------------------------------------------------------------
 * EEPROMSettings — exact copy of original struct from config.h
 * Only change: removed Arduino types, use stdint equivalents
 * ----------------------------------------------------------------------- */
typedef struct {
    uint8_t  version;
    uint8_t  checksum;
    uint32_t canSpeed;
    uint8_t  batteryID;
    uint8_t  logLevel;
    float    OverVSetpoint;
    float    UnderVSetpoint;
    float    DischHys;
    float    ChargeVsetpoint;
    float    DischVsetpoint;
    float    ChargeHys;
    float    StoreVsetpoint;
    float    WarnOff;
    float    OverTSetpoint;
    float    UnderTSetpoint;
    uint16_t triptime;
    float    ChargeTSetpoint;
    float    DisTSetpoint;
    float    WarnToff;
    float    CellGap;
    uint8_t  IgnoreTemp;
    float    IgnoreVolt;
    float    balanceVoltage;
    float    balanceHyst;
    int      Scells;
    int      Pstrings;
    int      CAP;
    uint16_t chargecurrentmax;
    uint16_t chargecurrent2max;
    uint16_t chargecurrentend;
    uint16_t discurrentmax;
    int      socvolt[4];
    int      invertcur;
    int      cursens;
    int      curcan;
    int      voltsoc;
    int      Pretime;
    int      conthold;
    int      Precurrent;
    float    convhigh;
    float    convlow;
    int32_t  changecur;
    uint16_t offset1;
    uint16_t offset2;
    int      balanceDuty;
    int      ESSmode;
    int      gaugelow;
    int      gaugehigh;
    int      ncur;
    int      chargertype;
    int      chargerspd;
    uint16_t UnderDur;
    uint16_t CurDead;
    float    DisTaper;
    uint8_t  ChargerDirect;
    uint8_t  ExpMess;
    uint8_t  SerialCan;
    uint16_t PulseCh;
    uint16_t PulseChDur;
    uint16_t PulseDi;
    uint16_t PulseDiDur;
    uint8_t  tripcont;
    int      chargereff;
    int      chargerACv;
} EEPROMSettings;

#endif /* CONFIG_H */
