#pragma once
/*
 * SerialConsole.h — STM32F103 port of TeslaBMSV2
 *
 * Exact same class interface as the original.
 * SERIALCONSOLE.available() / .read() → polled USART1 RX in loop()
 */

#ifndef SERIALCONSOLE_H_
#define SERIALCONSOLE_H_

#include "config.h"

class SerialConsole {
public:
    SerialConsole();
    void loop();
    void printMenu();

protected:
    enum CONSOLE_STATE {
        STATE_ROOT_MENU
    };

private:
    char cmdBuffer[80];
    int  ptrBuffer;
    int  state;
    int  loopcount;
    bool cancel;

    void init();
    void serialEvent();
    void handleConsoleCmd();
    void handleShortCmd();
};

#endif /* SERIALCONSOLE_H_ */
