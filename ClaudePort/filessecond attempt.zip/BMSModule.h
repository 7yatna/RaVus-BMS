#pragma once
/*
 * BMSModule.h — STM32F103 port of TeslaBMSV2
 *
 * Exact same class interface as the original.
 * No Arduino types needed — stdint.h covers everything.
 */

#ifndef BMSMODULE_H
#define BMSMODULE_H

#include <stdint.h>
#include <stdbool.h>

class BMSModule
{
public:
    BMSModule();
    void    readStatus();
    void    clearmodule();
    void    stopBalance();
    bool    readModuleValues();
    int     getscells();
    float   getCellVoltage(int cell);
    float   getLowCellV();
    float   getHighCellV();
    float   getAverageV();
    float   getLowTemp();
    float   getHighTemp();
    float   getHighestModuleVolt();
    float   getLowestModuleVolt();
    float   getHighestCellVolt(int cell);
    float   getLowestCellVolt(int cell);
    float   getHighestTemp();
    float   getLowestTemp();
    float   getAvgTemp();
    float   getModuleVoltage();
    float   getTemperature(int temp);
    uint8_t getFaults();
    uint8_t getAlerts();
    uint8_t getCOVCells();
    uint8_t getCUVCells();
    void    setAddress(int newAddr);
    int     getAddress();
    bool    isExisting();
    void    setExists(bool ex);
    void    settempsensor(int tempsensor);
    void    setIgnoreCell(float Ignore);

private:
    float   cellVolt[6];
    float   lowestCellVolt[6];
    float   highestCellVolt[6];
    float   moduleVolt;
    float   retmoduleVolt;
    float   temperatures[2];
    float   lowestTemperature;
    float   highestTemperature;
    float   lowestModuleVolt;
    float   highestModuleVolt;
    float   IgnoreCell;
    bool    exists;
    int     alerts;
    int     faults;
    int     COVFaults;
    int     CUVFaults;
    int     sensor;
    uint8_t moduleAddress;
    int     scells;
    int     smiss;
};

#endif /* BMSMODULE_H */
