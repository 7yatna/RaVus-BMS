/*
 * BMSModuleManager.cpp — STM32F103 port of TeslaBMSV2
 *
 * Near-verbatim port of the original. Key replacements:
 *
 *   delay(n)           → delay_ms(n)
 *   digitalRead(11)    → gpio_get(OUT1_PORT, OUT1_PIN)
 *                        (pin 11 = OUT1 = discharge contactor fault detect)
 *   Serial.print()     → Logger::console() / Logger::puts_()
 *   Serial2.print()    → Logger::console() (Nextion display — omitted, or
 *                         route to USART2 if display is wired)
 *   SERIALCONSOLE.print() → Logger::puts_() / Logger::console()
 *
 * printAllCSV() Serial2 output is sent to SERIALCONSOLE_USART instead
 * (the Nextion display is not part of the STM32 core port).
 */

#include "config.h"
#include "BMSModuleManager.h"
#include "BMSUtil.h"
#include "Logger.h"
#include <string.h>
#include <libopencm3/stm32/gpio.h>

extern EEPROMSettings settings;
extern void delay_ms(uint32_t ms);

/* Helper: print a float with given decimal places to console USART */
static void print_float(float val, int dp)
{
    char buf[32];
    /* Use snprintf from newlib — available with --specs=nosys.specs */
    if (dp == 0)       snprintf(buf, sizeof(buf), "%.0f", (double)val);
    else if (dp == 1)  snprintf(buf, sizeof(buf), "%.1f", (double)val);
    else if (dp == 2)  snprintf(buf, sizeof(buf), "%.2f", (double)val);
    else               snprintf(buf, sizeof(buf), "%.3f", (double)val);
    Logger::puts_(buf);
}

static void print_int_raw(int val)
{
    char buf[16];
    snprintf(buf, sizeof(buf), "%d", val);
    Logger::puts_(buf);
}

static void print_ulong_raw(unsigned long val)
{
    char buf[16];
    snprintf(buf, sizeof(buf), "%lu", val);
    Logger::puts_(buf);
}

/* -----------------------------------------------------------------------
 * Constructor — identical to original
 * ----------------------------------------------------------------------- */
BMSModuleManager::BMSModuleManager()
{
    for (int i = 1; i <= MAX_MODULE_ADDR; i++) {
        modules[i].setExists(false);
        modules[i].setAddress(i);
    }
    lowestPackVolt   = 1000.0f;
    highestPackVolt  = 0.0f;
    lowestPackTemp   = 200.0f;
    highestPackTemp  = -100.0f;
    isFaulted        = false;
    numFoundModules  = 0;
    packVolt         = 0.0f;
    Pstring          = 1;
    LowCellVolt      = 0.0f;
    HighCellVolt     = 0.0f;
    highTemp         = -999.0f;
    lowTemp          = 999.0f;
    batteryID        = 1;
    spack            = 0;
    CellsBalancing   = 0;
}

/* ----------------------------------------------------------------------- */
void BMSModuleManager::clearmodules()
{
    for (int y = 1; y < 63; y++) {
        if (modules[y].isExisting()) modules[y].clearmodule();
    }
}

/* ----------------------------------------------------------------------- */
int BMSModuleManager::seriescells()
{
    spack = 0;
    for (int y = 1; y < 63; y++) {
        if (modules[y].isExisting()) spack += modules[y].getscells();
    }
    return spack;
}

/* -----------------------------------------------------------------------
 * balanceCells() — identical logic, delay() → delay_ms()
 * debug Serial.print() → Logger::console()
 * ----------------------------------------------------------------------- */
void BMSModuleManager::balanceCells(int duration, int debug)
{
    uint8_t payload[4];
    uint8_t buff[30];
    uint8_t balance = 0;
    CellsBalancing  = 0;

    if (debug == 1) Logger::console("");

    for (int y = 1; y < 63; y++) {
        if (modules[y].isExisting() == 1) {
            balance = 0;
            for (int i = 0; i < 6; i++) {
                if (getLowCellVolt() < modules[y].getCellVoltage(i))
                    balance |= (1 << i);
            }
            if (debug == 1) {
                print_int_raw(y);
                Logger::puts_(" - ");
                /* print binary representation */
                for (int b = 7; b >= 0; b--)
                    Logger::putchar_((balance & (1 << b)) ? '1' : '0');
                Logger::puts_(" | ");
            }
            if (balance != 0) {
                payload[0] = y << 1;
                payload[1] = REG_BAL_TIME;
                payload[2] = (uint8_t)duration;
                BMSUtil::sendData(payload, 3, true);
                delay_ms(2);
                BMSUtil::getReply(buff, 30);

                if (debug == 1) {
                    for (int z = 0; z < 4; z++) {
                        char hex[4];
                        snprintf(hex, sizeof(hex), "%02X-", buff[z]);
                        Logger::puts_(hex);
                    }
                    Logger::puts_(" | ");
                }

                payload[0] = y << 1;
                payload[1] = REG_BAL_CTRL;
                payload[2] = balance;
                BMSUtil::sendData(payload, 3, true);
                delay_ms(2);
                BMSUtil::getReply(buff, 30);

                if (debug == 1) {
                    for (int z = 0; z < 4; z++) {
                        char hex[4];
                        snprintf(hex, sizeof(hex), "%02X-", buff[z]);
                        Logger::puts_(hex);
                    }
                }
                CellsBalancing += balance;
            }
            if (debug == 1) Logger::console("");
        }
    }
}

/* -----------------------------------------------------------------------
 * setupBoards() — identical to original, delay() → delay_ms()
 * ----------------------------------------------------------------------- */
void BMSModuleManager::setupBoards()
{
    uint8_t payload[3];
    uint8_t buff[10];
    int     retLen;

    while (1) {
        payload[0] = 0;
        payload[1] = 0;
        payload[2] = 1;
        retLen = BMSUtil::sendDataWithReply(payload, 3, false, buff, 4);
        if (retLen == 4) {
            if (buff[0] == 0x80 && buff[1] == 0 && buff[2] == 1) {
                Logger::debug("00 found");
                for (int y = 1; y < 63; y++) {
                    if (!modules[y].isExisting()) {
                        payload[0] = 0;
                        payload[1] = REG_ADDR_CTRL;
                        payload[2] = y | 0x80;
                        BMSUtil::sendData(payload, 3, true);
                        delay_ms(3);
                        if (BMSUtil::getReply(buff, 10) > 2) {
                            if (buff[0] == 0x81 && buff[1] == REG_ADDR_CTRL && buff[2] == (y + 0x80)) {
                                modules[y].setExists(true);
                                numFoundModules++;
                                Logger::debug("Address assigned");
                            }
                        }
                        break;
                    }
                }
            } else break;
        } else break;
    }
}

/* -----------------------------------------------------------------------
 * findBoards() — identical to original, delay() → delay_ms()
 * ----------------------------------------------------------------------- */
void BMSModuleManager::findBoards()
{
    uint8_t payload[3];
    uint8_t buff[8];

    numFoundModules = 0;
    payload[0] = 0;
    payload[1] = 0;
    payload[2] = 1;
    for (int x = 1; x <= MAX_MODULE_ADDR; x++) {
        modules[x].setExists(false);
        payload[0] = x << 1;
        BMSUtil::sendData(payload, 3, false);
        delay_ms(20);
        if (BMSUtil::getReply(buff, 8) > 4) {
            if (buff[0] == (x << 1) && buff[1] == 0 && buff[2] == 1 && buff[4] > 0) {
                modules[x].setExists(true);
                numFoundModules++;
            }
        }
        delay_ms(5);
    }
}

/* -----------------------------------------------------------------------
 * renumberBoardIDs() — identical to original, delay() → delay_ms()
 * ----------------------------------------------------------------------- */
void BMSModuleManager::renumberBoardIDs()
{
    uint8_t payload[3];
    uint8_t buff[8];
    int     attempts = 1;

    for (int y = 1; y < 63; y++) {
        modules[y].setExists(false);
        numFoundModules = 0;
    }

    while (attempts < 3) {
        payload[0] = 0x3F << 1;
        payload[1] = 0x3C;
        payload[2] = 0xA5;
        BMSUtil::sendData(payload, 3, true);
        delay_ms(100);
        BMSUtil::getReply(buff, 8);
        if (buff[0] == 0x7F && buff[1] == 0x3C && buff[2] == 0xA5 && buff[3] == 0x57) break;
        attempts++;
    }

    setupBoards();
}

/* -----------------------------------------------------------------------
 * clearFaults() — identical to original
 * ----------------------------------------------------------------------- */
void BMSModuleManager::clearFaults()
{
    uint8_t payload[3];
    uint8_t buff[8];

    payload[0] = 0x7F;
    payload[1] = REG_ALERT_STATUS;
    payload[2] = 0xFF;
    BMSUtil::sendDataWithReply(payload, 3, true, buff, 4);
    payload[2] = 0x00;
    BMSUtil::sendDataWithReply(payload, 3, true, buff, 4);

    payload[1] = REG_FAULT_STATUS;
    payload[2] = 0xFF;
    BMSUtil::sendDataWithReply(payload, 3, true, buff, 4);
    payload[2] = 0x00;
    BMSUtil::sendDataWithReply(payload, 3, true, buff, 4);

    isFaulted = false;
}

/* -----------------------------------------------------------------------
 * sleepBoards() / wakeBoards() — identical, delay() → delay_ms()
 * ----------------------------------------------------------------------- */
void BMSModuleManager::sleepBoards()
{
    uint8_t payload[3];
    uint8_t buff[8];
    payload[0] = 0x7F;
    payload[1] = REG_IO_CTRL;
    payload[2] = 0x04;
    BMSUtil::sendData(payload, 3, true);
    delay_ms(2);
    BMSUtil::getReply(buff, 8);
}

void BMSModuleManager::wakeBoards()
{
    uint8_t payload[3];
    uint8_t buff[8];

    payload[0] = 0x7F;
    payload[1] = REG_IO_CTRL;
    payload[2] = 0x00;
    BMSUtil::sendData(payload, 3, true);
    delay_ms(2);
    BMSUtil::getReply(buff, 8);

    payload[0] = 0x7F;
    payload[1] = REG_ALERT_STATUS;
    payload[2] = 0x04;
    BMSUtil::sendData(payload, 3, true);
    delay_ms(2);
    BMSUtil::getReply(buff, 8);

    payload[0] = 0x7F;
    payload[2] = 0x00;
    BMSUtil::sendData(payload, 3, true);
    delay_ms(2);
    BMSUtil::getReply(buff, 8);
}

/* -----------------------------------------------------------------------
 * StopBalancing()
 * ----------------------------------------------------------------------- */
void BMSModuleManager::StopBalancing()
{
    for (int x = 1; x <= MAX_MODULE_ADDR; x++) {
        if (modules[x].isExisting()) modules[x].stopBalance();
    }
}

/* -----------------------------------------------------------------------
 * getAllVoltTemp() — identical logic
 *
 * Original used: digitalRead(11) to detect module fault (BMBfault pin).
 * STM32 port: gpio_get(OUT1_PORT, OUT1_PIN) — same physical meaning.
 * Adjust if your hardware uses a different fault-detect pin.
 *
 * delay() → delay_ms()
 * ----------------------------------------------------------------------- */
void BMSModuleManager::getAllVoltTemp()
{
    packVolt = 0.0f;

    for (int x = 1; x <= MAX_MODULE_ADDR; x++) {
        if (modules[x].isExisting()) modules[x].stopBalance();
    }

    if (numFoundModules < 8) delay_ms(200);
    else                      delay_ms(50);

    for (int x = 1; x <= MAX_MODULE_ADDR; x++) {
        if (modules[x].isExisting()) {
            Logger::debug("");
            Logger::debug("Module %i exists. Reading voltage and temperature values", x);
            modules[x].readModuleValues();
            Logger::debug("Module voltage: %f", modules[x].getModuleVoltage());
            Logger::debug("Lowest Cell V: %f     Highest Cell V: %f",
                          modules[x].getLowCellV(), modules[x].getHighCellV());
            Logger::debug("Temp1: %f       Temp2: %f",
                          modules[x].getTemperature(0), modules[x].getTemperature(1));
            packVolt += modules[x].getModuleVoltage();
            if (modules[x].getLowTemp()  < lowestPackTemp  && modules[x].getLowTemp()  > -70)
                lowestPackTemp  = modules[x].getLowTemp();
            if (modules[x].getHighTemp() > highestPackTemp && modules[x].getLowTemp()  > -70)
                highestPackTemp = modules[x].getHighTemp();
        }
    }

    packVolt /= Pstring;
    if (packVolt > highestPackVolt) highestPackVolt = packVolt;
    if (packVolt < lowestPackVolt)  lowestPackVolt  = packVolt;

    /*
     * Original read digitalRead(11) — BMBfault pin (OUT1 / discharge contactor).
     * On STM32 we read OUT1_PIN instead.
     * If your fault pin is wired differently, change OUT1_PORT/OUT1_PIN here.
     */
    if (gpio_get(OUT1_PORT, OUT1_PIN) == 0) {
        if (!isFaulted) Logger::error("One or more BMS modules have entered the fault state!");
        isFaulted = true;
    } else {
        if (isFaulted) Logger::info("All modules have exited a faulted state");
        isFaulted = false;
    }

    HighCellVolt = 0.0f;
    for (int x = 1; x <= MAX_MODULE_ADDR; x++) {
        if (modules[x].isExisting())
            if (modules[x].getHighCellV() > HighCellVolt) HighCellVolt = modules[x].getHighCellV();
    }
    LowCellVolt = 5.0f;
    for (int x = 1; x <= MAX_MODULE_ADDR; x++) {
        if (modules[x].isExisting())
            if (modules[x].getLowCellV() < LowCellVolt) LowCellVolt = modules[x].getLowCellV();
    }
}

/* -----------------------------------------------------------------------
 * Setters / getters — identical to original
 * ----------------------------------------------------------------------- */
int   BMSModuleManager::getBalancing()   { return CellsBalancing; }
float BMSModuleManager::getLowCellVolt() { return LowCellVolt; }
float BMSModuleManager::getHighCellVolt(){ return HighCellVolt; }
float BMSModuleManager::getPackVoltage() { return packVolt; }
float BMSModuleManager::getLowVoltage()  { return lowestPackVolt; }
float BMSModuleManager::getHighVoltage() { return highestPackVolt; }
int   BMSModuleManager::getNumModules()  { return numFoundModules; }

void BMSModuleManager::setBatteryID(int id)    { batteryID = id; }
void BMSModuleManager::setPstrings(int Pstrings) { Pstring = Pstrings; }

void BMSModuleManager::setSensors(int sensor, float Ignore)
{
    for (int x = 1; x <= MAX_MODULE_ADDR; x++) {
        if (modules[x].isExisting()) {
            modules[x].settempsensor(sensor);
            modules[x].setIgnoreCell(Ignore);
        }
    }
}

/* -----------------------------------------------------------------------
 * getAvgTemperature() — also updates highTemp / lowTemp (identical logic)
 * ----------------------------------------------------------------------- */
float BMSModuleManager::getAvgTemperature()
{
    float avg = 0.0f;
    lowTemp  = 999.0f;
    highTemp = -999.0f;
    int y = 0;
    for (int x = 1; x <= MAX_MODULE_ADDR; x++) {
        if (modules[x].isExisting()) {
            if (modules[x].getAvgTemp() > -70) {
                avg += modules[x].getAvgTemp();
                if (modules[x].getHighTemp() > highTemp) highTemp = modules[x].getHighTemp();
                if (modules[x].getLowTemp()  < lowTemp)  lowTemp  = modules[x].getLowTemp();
            } else {
                y++;
            }
        }
    }
    if ((numFoundModules - y) > 0)
        avg /= (float)(numFoundModules - y);
    return avg;
}

float BMSModuleManager::getHighTemperature() { return highTemp; }
float BMSModuleManager::getLowTemperature()  { return lowTemp; }

float BMSModuleManager::getAvgCellVolt()
{
    float avg = 0.0f;
    for (int x = 1; x <= MAX_MODULE_ADDR; x++) {
        if (modules[x].isExisting()) avg += modules[x].getAverageV();
    }
    if (numFoundModules > 0) avg /= (float)numFoundModules;
    return avg;
}

uint16_t BMSModuleManager::getcellvolt(int modid, int cellid)
{
    return (uint16_t)(modules[modid].getCellVoltage(cellid) * 1000.0f);
}

uint16_t BMSModuleManager::gettemp(int modid, int tempid)
{
    return (uint16_t)modules[modid].getTemperature(tempid);
}

/* -----------------------------------------------------------------------
 * printPackSummary() — SERIALCONSOLE.print() → Logger::console() / puts_()
 * ----------------------------------------------------------------------- */
void BMSModuleManager::printPackSummary()
{
    uint8_t faults, alerts, COV, CUV;

    Logger::console("");
    Logger::console("Modules: %i    Voltage: %fV   Avg Cell Voltage: %fV     Avg Temp: %fC",
                    numFoundModules, getPackVoltage(), getAvgCellVolt(), getAvgTemperature());
    Logger::console("");

    for (int y = 1; y < 63; y++) {
        if (!modules[y].isExisting()) continue;

        faults = modules[y].getFaults();
        alerts = modules[y].getAlerts();
        COV    = modules[y].getCOVCells();
        CUV    = modules[y].getCUVCells();

        Logger::console("                               Module #%i", y);
        Logger::console("  Voltage: %fV   (%fV-%fV)     Temperatures: (%fC-%fC)",
                        modules[y].getModuleVoltage(),
                        modules[y].getLowCellV(), modules[y].getHighCellV(),
                        modules[y].getLowTemp(),  modules[y].getHighTemp());

        if (faults > 0) {
            Logger::console("  MODULE IS FAULTED:");
            if (faults & 1) {
                Logger::puts_("    Overvoltage Cell Numbers (1-6): ");
                for (int i = 0; i < 6; i++) if (COV & (1 << i)) { print_int_raw(i+1); Logger::putchar_(' '); }
                Logger::puts_("\r\n");
            }
            if (faults & 2) {
                Logger::puts_("    Undervoltage Cell Numbers (1-6): ");
                for (int i = 0; i < 6; i++) if (CUV & (1 << i)) { print_int_raw(i+1); Logger::putchar_(' '); }
                Logger::puts_("\r\n");
            }
            if (faults & 4)  Logger::console("    CRC error in received packet");
            if (faults & 8)  Logger::console("    Power on reset has occurred");
            if (faults & 0x10) Logger::console("    Test fault active");
            if (faults & 0x20) Logger::console("    Internal registers inconsistent");
        }
        if (alerts > 0) {
            Logger::console("  MODULE HAS ALERTS:");
            if (alerts & 1)    Logger::console("    Over temperature on TS1");
            if (alerts & 2)    Logger::console("    Over temperature on TS2");
            if (alerts & 4)    Logger::console("    Sleep mode active");
            if (alerts & 8)    Logger::console("    Thermal shutdown active");
            if (alerts & 0x10) Logger::console("    Test Alert");
            if (alerts & 0x20) Logger::console("    OTP EPROM Uncorrectable Error");
            if (alerts & 0x40) Logger::console("    GROUP3 Regs Invalid");
            if (alerts & 0x80) Logger::console("    Address not registered");
        }
        if (faults > 0 || alerts > 0) Logger::console("");
    }
}

/* -----------------------------------------------------------------------
 * printPackDetails() — SERIALCONSOLE.print() → Logger::puts_() chain
 * ----------------------------------------------------------------------- */
void BMSModuleManager::printPackDetails(int digits)
{
    int cellNum = 0;

    Logger::console("");
    Logger::console("Modules: %i Cells: %i Strings: %i  Voltage: %fV   Avg: %fV  Low: %fV  High: %fV  Delta: %zmV  Avg Temp: %fC",
                    numFoundModules, seriescells(), Pstring,
                    getPackVoltage(), getAvgCellVolt(), LowCellVolt, HighCellVolt,
                    (double)(HighCellVolt - LowCellVolt) * 1000.0, getAvgTemperature());
    Logger::console("");

    for (int y = 1; y < 63; y++) {
        if (!modules[y].isExisting()) continue;

        Logger::puts_("Module #");
        print_int_raw(y);
        if (y < 10) Logger::putchar_(' ');
        Logger::puts_("  ");
        print_float(modules[y].getModuleVoltage(), digits);
        Logger::puts_("V");

        for (int i = 0; i < 6; i++) {
            if (cellNum < 10) Logger::putchar_(' ');
            Logger::puts_("  Cell");
            print_int_raw(cellNum++);
            Logger::puts_(": ");
            print_float(modules[y].getCellVoltage(i), digits);
            Logger::puts_("V");
        }
        Logger::puts_("  Neg Term Temp: ");
        print_float(modules[y].getTemperature(0), 1);
        Logger::puts_("C  Pos Term Temp: ");
        print_float(modules[y].getTemperature(1), 1);
        Logger::puts_("C\r\n");
    }
}

/* -----------------------------------------------------------------------
 * printAllCSV() — routes both SERIALCONSOLE and Serial2 to USART1
 * (The Nextion Serial2 display is not part of the core STM32 port.
 *  Wire USART2 separately if a Nextion display is connected.)
 * ----------------------------------------------------------------------- */
void BMSModuleManager::printAllCSV(unsigned long timestamp, float current, int SOC, int delim)
{
    const char *sep = (delim == 1) ? " " : ",";

    for (int y = 1; y < 63; y++) {
        if (!modules[y].isExisting()) continue;
        print_ulong_raw(timestamp); Logger::puts_(sep);
        print_float(current, 0);   Logger::puts_(sep);
        print_int_raw(SOC);        Logger::puts_(sep);
        print_int_raw(y);          Logger::puts_(sep);
        for (int i = 0; i < 6; i++) {
            print_float(modules[y].getCellVoltage(i), 4);
            Logger::puts_(sep);
        }
        print_float(modules[y].getTemperature(0), 1); Logger::puts_(sep);
        print_float(modules[y].getTemperature(1), 1); Logger::puts_("\r\n");
    }
}

/* -----------------------------------------------------------------------
 * Stub setters (original had these as setpoints for modules)
 * ----------------------------------------------------------------------- */
void BMSModuleManager::setUnderVolt(float newVal)  { (void)newVal; }
void BMSModuleManager::setOverVolt(float newVal)   { (void)newVal; }
void BMSModuleManager::setOverTemp(float newVal)   { (void)newVal; }
void BMSModuleManager::setBalanceV(float newVal)   { (void)newVal; }
void BMSModuleManager::setBalanceHyst(float newVal){ (void)newVal; }
void BMSModuleManager::readSetpoints()             {}
