/*
 * Logger.cpp — STM32F103 port of TeslaBMSV2 Logger
 *
 * Replaces: Arduino Serial.print() calls throughout
 * Output: USART1 (PA9 TX / PA10 RX) @ 115200 baud
 *
 * The custom printf-style format specifiers from the original are preserved:
 *   %s %d/%i %f %z %x %X %b %B %l %c %t %T
 *
 * millis() → system_ms (SysTick-driven uint32_t in main.cpp)
 */

#include "Logger.h"
#include "config.h"
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include <libopencm3/stm32/rcc.h>
#include <libopencm3/stm32/gpio.h>
#include <libopencm3/stm32/usart.h>

Logger::LogLevel Logger::logLevel  = Logger::Info;
uint32_t         Logger::lastLogTime = 0;

/* -----------------------------------------------------------------------
 * Low-level USART1 character output
 * Called by all Logger methods instead of Serial.print()
 * ----------------------------------------------------------------------- */
void Logger::putchar_(char c)
{
    usart_send_blocking(SERIALCONSOLE_USART, (uint16_t)c);
}

void Logger::puts_(const char *s)
{
    while (*s) putchar_(*s++);
}

/* -----------------------------------------------------------------------
 * Helper: print uint32_t in given base (replaces Arduino print(val, BASE))
 * ----------------------------------------------------------------------- */
static void print_uint(uint32_t val, int base)
{
    if (val == 0) { Logger::putchar_('0'); return; }
    char buf[33];
    int  idx = 0;
    while (val > 0) {
        int d = val % base;
        buf[idx++] = (d < 10) ? ('0' + d) : ('a' + d - 10);
        val /= base;
    }
    /* reverse */
    for (int i = idx - 1; i >= 0; i--) Logger::putchar_(buf[i]);
}

static void print_int(int32_t val, int base)
{
    if (val < 0) { Logger::putchar_('-'); val = -val; }
    print_uint((uint32_t)val, base);
}

static void print_double(double val, int decimals)
{
    if (val < 0) { Logger::putchar_('-'); val = -val; }
    uint32_t intPart = (uint32_t)val;
    print_uint(intPart, 10);
    if (decimals > 0) {
        Logger::putchar_('.');
        double frac = val - (double)intPart;
        for (int i = 0; i < decimals; i++) {
            frac *= 10.0;
            int d = (int)frac;
            Logger::putchar_('0' + d);
            frac -= d;
        }
    }
}

/* -----------------------------------------------------------------------
 * debug / info / warn / error / console — match original signatures exactly
 * ----------------------------------------------------------------------- */
void Logger::debug(const char *message, ...) {
    if (logLevel > Debug) return;
    va_list args;
    va_start(args, message);
    Logger::log(Debug, message, args);
    va_end(args);
}

void Logger::info(const char *message, ...) {
    if (logLevel > Info) return;
    va_list args;
    va_start(args, message);
    Logger::log(Info, message, args);
    va_end(args);
}

void Logger::warn(const char *message, ...) {
    if (logLevel > Warn) return;
    va_list args;
    va_start(args, message);
    Logger::log(Warn, message, args);
    va_end(args);
}

void Logger::error(const char *message, ...) {
    if (logLevel > Error) return;
    va_list args;
    va_start(args, message);
    Logger::log(Error, message, args);
    va_end(args);
}

void Logger::console(const char *message, ...) {
    va_list args;
    va_start(args, message);
    Logger::logMessage(message, args);
    va_end(args);
}

void Logger::setLoglevel(LogLevel level) { logLevel = level; }
Logger::LogLevel Logger::getLogLevel()   { return logLevel; }
uint32_t Logger::getLastLogTime()        { return lastLogTime; }
bool Logger::isDebug()                   { return logLevel == Debug; }

/* -----------------------------------------------------------------------
 * log() — prepend timestamp + level tag, then call logMessage()
 * Replaces: millis() → system_ms
 *           SERIALCONSOLE.print() → Logger::puts_()
 * ----------------------------------------------------------------------- */
void Logger::log(LogLevel level, const char *format, va_list args)
{
    lastLogTime = system_ms; /* replaces millis() */
    print_uint(lastLogTime, 10);
    puts_(" - ");
    switch (level) {
        case Debug: puts_("DEBUG");   break;
        case Info:  puts_("INFO");    break;
        case Warn:  puts_("WARNING"); break;
        case Error: puts_("ERROR");   break;
        default: break;
    }
    puts_(": ");
    logMessage(format, args);
}

/* -----------------------------------------------------------------------
 * logMessage() — custom printf interpreter matching original exactly
 *
 * Supported specifiers (from original Logger.cpp):
 *   %%  literal %
 *   %s  string
 *   %d  decimal int   (%i also accepted)
 *   %f  float (3 dp)
 *   %z  float (0 dp)  — custom specifier in original code
 *   %x  hex lowercase
 *   %X  hex with "0x" prefix
 *   %b  binary
 *   %B  binary with "0b" prefix
 *   %l  long decimal
 *   %c  character
 *   %t  boolean as T/F
 *   %T  boolean as TRUE/FALSE
 * ----------------------------------------------------------------------- */
void Logger::logMessage(const char *format, va_list args)
{
    for (; *format != '\0'; ++format) {
        if (*format != '%') {
            putchar_(*format);
            continue;
        }
        ++format;
        if (*format == '\0') break;

        switch (*format) {
        case '%':
            putchar_('%');
            break;
        case 's': {
            const char *s = va_arg(args, const char *);
            puts_(s ? s : "(null)");
            break;
        }
        case 'd':
        case 'i':
            print_int(va_arg(args, int), 10);
            break;
        case 'f':
            print_double(va_arg(args, double), 3);
            break;
        case 'z':   /* original custom: float with 0 decimal places */
            print_double(va_arg(args, double), 0);
            break;
        case 'x':
            print_uint((uint32_t)va_arg(args, unsigned int), 16);
            break;
        case 'X':
            puts_("0x");
            print_uint((uint32_t)va_arg(args, unsigned int), 16);
            break;
        case 'b':
            print_uint((uint32_t)va_arg(args, unsigned int), 2);
            break;
        case 'B':
            puts_("0b");
            print_uint((uint32_t)va_arg(args, unsigned int), 2);
            break;
        case 'l':
            print_int((int32_t)va_arg(args, long), 10);
            break;
        case 'c':
            putchar_((char)va_arg(args, int));
            break;
        case 't':
            putchar_(va_arg(args, int) ? 'T' : 'F');
            break;
        case 'T':
            puts_(va_arg(args, int) ? "TRUE" : "FALSE");
            break;
        default:
            putchar_('%');
            putchar_(*format);
            break;
        }
    }
    puts_("\r\n");
}
