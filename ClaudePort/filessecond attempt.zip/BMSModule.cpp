/*
 * BMSModule.cpp — STM32F103 port of TeslaBMSV2
 *
 * This is a near-verbatim port of the original BMSModule.cpp.
 *
 * Changes from original:
 *   #include <Arduino.h>         → removed
 *   delay(n)                     → delay_ms(n)
 *   Logger::debug/error()        → unchanged (Logger is ported)
 *   BMSUtil::sendDataWithReply() → unchanged (BMSUtil is ported)
 *
 * All voltage/temperature conversion math is identical to the original.
 * The Steinhart-Hart equation and cell voltage scaling are untouched.
 */

#include "config.h"
#include "BMSModule.h"
#include "BMSUtil.h"
#include "Logger.h"
#include <math.h>

extern void delay_ms(uint32_t ms);

BMSModule::BMSModule()
{
    for (int i = 0; i < 6; i++) {
        cellVolt[i]        = 0.0f;
        lowestCellVolt[i]  = 5.0f;
        highestCellVolt[i] = 0.0f;
    }
    moduleVolt        = 0.0f;
    retmoduleVolt     = 0.0f;
    temperatures[0]   = 0.0f;
    temperatures[1]   = 0.0f;
    lowestTemperature  = 200.0f;
    highestTemperature = -100.0f;
    lowestModuleVolt   = 200.0f;
    highestModuleVolt  = 0.0f;
    moduleAddress      = 0;
    exists             = false;
    alerts             = 0;
    faults             = 0;
    COVFaults          = 0;
    CUVFaults          = 0;
    sensor             = 0;
    scells             = 6;
    smiss              = 0;
    IgnoreCell         = 0.0f;
}

void BMSModule::clearmodule()
{
    for (int i = 0; i < 6; i++) cellVolt[i] = 0.0f;
    moduleVolt      = 0.0f;
    temperatures[0] = 0.0f;
    temperatures[1] = 0.0f;
}

/*
 * readStatus() — read DEV_STATUS and ALERT/FAULT registers
 * Identical to original. delay() → delay_ms()
 */
void BMSModule::readStatus()
{
    uint8_t payload[3];
    uint8_t buff[8];

    payload[0] = moduleAddress << 1;
    payload[1] = REG_DEV_STATUS;
    payload[2] = 0x01;
    BMSUtil::sendDataWithReply(payload, 3, false, buff, 4);

    payload[0] = moduleAddress << 1;
    payload[1] = REG_ALERT_STATUS;
    payload[2] = 0x04;
    BMSUtil::sendDataWithReply(payload, 3, false, buff, 7);
    alerts    = buff[3];
    faults    = buff[4];
    COVFaults = buff[5];
    CUVFaults = buff[6];

    payload[0] = moduleAddress << 1;
    payload[1] = REG_BAL_TIME;
    payload[2] = 0x01;
    BMSUtil::sendDataWithReply(payload, 3, false, buff, 4);
}

uint8_t BMSModule::getFaults()    { return faults;    }
uint8_t BMSModule::getAlerts()    { return alerts;    }
uint8_t BMSModule::getCOVCells()  { return COVFaults; }
uint8_t BMSModule::getCUVCells()  { return CUVFaults; }

/*
 * stopBalance() — send zero to REG_BAL_CTRL
 * delay() → delay_ms()
 */
void BMSModule::stopBalance()
{
    uint8_t buff[8];
    uint8_t payload[4];
    payload[0] = moduleAddress << 1;
    payload[1] = REG_BAL_CTRL;
    payload[2] = 0;
    BMSUtil::sendDataWithReply(payload, 3, true, buff, 4);
    delay_ms(2);
}

/*
 * readModuleValues() — main data read: voltages + temperatures
 *
 * Exact port of original. Key formulae preserved:
 *   retmoduleVolt = (raw16) * 0.0020346293922562
 *   cellVolt[i]   = (raw16) * 0.000381493
 *   temperatures: Steinhart-Hart with original magic constants
 *
 * delay() → delay_ms()
 */
bool BMSModule::readModuleValues()
{
    uint8_t payload[4];
    uint8_t buff[50];
    uint8_t calcCRC;
    bool    retVal = false;
    int     retLen;
    float   tempCalc;
    float   tempTemp;

    payload[0] = moduleAddress << 1;
    delay_ms(2);

    payload[0] = moduleAddress << 1;

    readStatus();
    Logger::debug("Module %i   alerts=%X   faults=%X   COV=%X   CUV=%X",
                  moduleAddress, alerts, faults, COVFaults, CUVFaults);

    payload[1] = REG_ADC_CTRL;
    payload[2] = 0b00111101; /* ADC Auto, both temps, pack, 6 cells */
    BMSUtil::sendDataWithReply(payload, 3, true, buff, 3);

    payload[1] = REG_IO_CTRL;
    payload[2] = 0b00000011; /* enable temperature VSS pins */
    BMSUtil::sendDataWithReply(payload, 3, true, buff, 3);

    payload[1] = REG_ADC_CONV;
    payload[2] = 1;
    BMSUtil::sendDataWithReply(payload, 3, true, buff, 3);

    payload[1] = REG_GPAI;
    payload[2] = 0x12; /* read 18 bytes: ModuleV + 6 cells + 2 temps */
    retLen = BMSUtil::sendDataWithReply(payload, 3, false, buff, 22);

    calcCRC = BMSUtil::genCRC(buff, retLen - 1);
    Logger::debug("Sent CRC: %x     Calculated CRC: %x", buff[21], calcCRC);

    if ((retLen == 22) && (buff[21] == calcCRC))
    {
        if (buff[0] == (moduleAddress << 1) && buff[1] == REG_GPAI && buff[2] == 0x12)
        {
            /* Module voltage: 16-bit raw * scaling factor (original constant) */
            retmoduleVolt = (buff[3] * 256 + buff[4]) * 0.0020346293922562f;
            if (retmoduleVolt > highestModuleVolt) highestModuleVolt = retmoduleVolt;
            if (retmoduleVolt < lowestModuleVolt)  lowestModuleVolt  = retmoduleVolt;

            /* Cell voltages: 16-bit raw * scaling factor (original constant) */
            for (int i = 0; i < 6; i++) {
                cellVolt[i] = (buff[5 + (i * 2)] * 256 + buff[6 + (i * 2)]) * 0.000381493f;
                if (lowestCellVolt[i]  > cellVolt[i] && cellVolt[i] >= IgnoreCell)
                    lowestCellVolt[i] = cellVolt[i];
                if (highestCellVolt[i] < cellVolt[i])
                    highestCellVolt[i] = cellVolt[i];
            }

            /* Module voltage = sum of cells */
            moduleVolt = 0;
            for (int i = 0; i < 6; i++) moduleVolt += cellVolt[i];

            /* Temperature 1 — Steinhart-Hart (original magic constants preserved exactly) */
            tempTemp = (1.78f / ((buff[17] * 256 + buff[18] + 2) / 33046.0f) - 3.57f);
            tempTemp *= 1000.0f;
            tempCalc = 1.0f / (0.0007610373573f
                             + (0.0002728524832f  * logf(tempTemp))
                             + (powf(logf(tempTemp), 3) * 0.0000001022822735f));
            temperatures[0] = tempCalc - 273.15f;

            /* Temperature 2 */
            tempTemp = 1.78f / ((buff[19] * 256 + buff[20] + 9) / 33068.0f) - 3.57f;
            tempTemp *= 1000.0f;
            tempCalc = 1.0f / (0.0007610373573f
                             + (0.0002728524832f  * logf(tempTemp))
                             + (powf(logf(tempTemp), 3) * 0.0000001022822735f));
            temperatures[1] = tempCalc - 273.15f;

            if (getLowTemp()  < lowestTemperature)  lowestTemperature  = getLowTemp();
            if (getHighTemp() > highestTemperature)  highestTemperature = getHighTemp();

            Logger::debug("Got voltage and temperature readings");
            retVal = true;
        }
    }
    else
    {
        Logger::error("Invalid module response received for module %i  len: %i   crc: %i   calc: %i",
                      moduleAddress, retLen, buff[21], calcCRC);
    }

    return retVal;
}

float BMSModule::getCellVoltage(int cell)
{
    if (cell < 0 || cell > 5) return 0.0f;
    return cellVolt[cell];
}

float BMSModule::getLowCellV()
{
    float lowVal = 10.0f;
    for (int i = 0; i < 6; i++)
        if (cellVolt[i] < lowVal && cellVolt[i] > IgnoreCell) lowVal = cellVolt[i];
    return lowVal;
}

float BMSModule::getHighCellV()
{
    float hiVal = 0.0f;
    for (int i = 0; i < 6; i++)
        if (cellVolt[i] > hiVal && cellVolt[i] < 4.5f) hiVal = cellVolt[i];
    return hiVal;
}

float BMSModule::getAverageV()
{
    int   x      = 0;
    float avgVal = 0.0f;
    for (int i = 0; i < 6; i++) {
        if (cellVolt[i] > IgnoreCell && cellVolt[i] < 60.0f) {
            x++;
            avgVal += cellVolt[i];
        }
    }
    if (scells != x) {
        if (smiss > 2) scells = x;
        else            smiss++;
    } else {
        scells = x;
        smiss  = 0;
    }
    if (x == 0) return 0.0f;
    avgVal /= x;
    return avgVal;
}

int   BMSModule::getscells()            { return scells; }
float BMSModule::getHighestModuleVolt() { return highestModuleVolt; }
float BMSModule::getLowestModuleVolt()  { return lowestModuleVolt; }

float BMSModule::getHighestCellVolt(int cell)
{
    if (cell < 0 || cell > 5) return 0.0f;
    return highestCellVolt[cell];
}

float BMSModule::getLowestCellVolt(int cell)
{
    if (cell < 0 || cell > 5) return 0.0f;
    return lowestCellVolt[cell];
}

float BMSModule::getHighestTemp() { return highestTemperature; }
float BMSModule::getLowestTemp()  { return lowestTemperature; }

float BMSModule::getLowTemp()
{
    if (sensor == 0)
        return (temperatures[0] < temperatures[1]) ? temperatures[0] : temperatures[1];
    return temperatures[sensor - 1];
}

float BMSModule::getHighTemp()
{
    if (sensor == 0)
        return (temperatures[0] < temperatures[1]) ? temperatures[1] : temperatures[0];
    return temperatures[sensor - 1];
}

float BMSModule::getAvgTemp()
{
    if (sensor == 0)
        return (temperatures[0] + temperatures[1]) * 0.5f;
    return temperatures[sensor - 1];
}

float BMSModule::getModuleVoltage()    { return moduleVolt; }

float BMSModule::getTemperature(int temp)
{
    if (temp < 0 || temp > 1) return 0.0f;
    return temperatures[temp];
}

void BMSModule::setAddress(int newAddr)
{
    if (newAddr < 0 || newAddr > MAX_MODULE_ADDR) return;
    moduleAddress = (uint8_t)newAddr;
}

int  BMSModule::getAddress()         { return moduleAddress; }
bool BMSModule::isExisting()         { return exists; }
void BMSModule::setExists(bool ex)   { exists = ex; }
void BMSModule::settempsensor(int t) { sensor = t; }
void BMSModule::setIgnoreCell(float Ignore) { IgnoreCell = Ignore; }
