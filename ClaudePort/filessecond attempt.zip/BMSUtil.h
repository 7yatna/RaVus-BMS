#pragma once
/*
 * BMSUtil.h — STM32F103 port of TeslaBMSV2
 *
 * Direct port of the original BMSUtil header-only class.
 *
 * Key replacements vs. original:
 *   SERIALBMS.write()     → usart_send_blocking(SERIALBMS_USART, ...)
 *   SERIALBMS.available() → (USART_SR(SERIALBMS_USART) & USART_SR_RXNE)
 *   SERIALBMS.read()      → usart_recv(SERIALBMS_USART)
 *   delay(n)              → delay_ms(n)  [declared extern, defined in main.cpp]
 *   Logger::isDebug()     → same (Logger class is ported)
 *   SERIALCONSOLE.print() → Logger::puts_() / Logger::putchar_()
 *
 * The CRC algorithm (polynomial 0x07) and protocol framing are unchanged.
 */

#ifndef BMSUTIL_H
#define BMSUTIL_H

#include <stdint.h>
#include "Logger.h"
#include "config.h"
#include <libopencm3/stm32/usart.h>

/* Declared in main.cpp */
extern void delay_ms(uint32_t ms);
extern volatile uint32_t system_ms;

/* Per-byte receive timeout on the BMS UART (ms) */
#define BMS_BYTE_TIMEOUT_MS   5

class BMSUtil {
public:

    /* -------------------------------------------------------------------
     * genCRC() — CRC-8 with polynomial 0x07
     * Identical to original — no changes needed.
     * ------------------------------------------------------------------- */
    static uint8_t genCRC(uint8_t *input, int lenInput)
    {
        uint8_t generator = 0x07;
        uint8_t crc = 0;
        for (int x = 0; x < lenInput; x++) {
            crc ^= input[x];
            for (int i = 0; i < 8; i++) {
                if ((crc & 0x80) != 0)
                    crc = (uint8_t)((crc << 1) ^ generator);
                else
                    crc <<= 1;
            }
        }
        return crc;
    }

    /* -------------------------------------------------------------------
     * sendData() — transmit a BMS packet over USART3
     *
     * Original used: SERIALBMS.write(addrByte)
     *                SERIALBMS.write(&data[1], dataLen-1)
     * Port uses:     usart_send_blocking(SERIALBMS_USART, byte)
     *
     * isWrite=true  → OR address byte with 0x01, append CRC
     * isWrite=false → read request, no CRC appended
     * ------------------------------------------------------------------- */
    static void sendData(uint8_t *data, uint8_t dataLen, bool isWrite)
    {
        uint8_t orig    = data[0];
        uint8_t addrByte = data[0];
        if (isWrite) addrByte |= 1;

        /* Flush any stale RX bytes before sending */
        while (USART_SR(SERIALBMS_USART) & USART_SR_RXNE)
            (void)usart_recv(SERIALBMS_USART);

        usart_send_blocking(SERIALBMS_USART, addrByte);
        for (int i = 1; i < dataLen; i++)
            usart_send_blocking(SERIALBMS_USART, data[i]);

        data[0] = addrByte;
        if (isWrite)
            usart_send_blocking(SERIALBMS_USART, genCRC(data, dataLen));

        if (Logger::isDebug()) {
            Logger::puts_("Sending: ");
            char hex[4];
            snprintf_hex(hex, addrByte);
            Logger::puts_(hex);
            Logger::putchar_(' ');
            for (int x = 1; x < dataLen; x++) {
                snprintf_hex(hex, data[x]);
                Logger::puts_(hex);
                Logger::putchar_(' ');
            }
            if (isWrite) {
                snprintf_hex(hex, genCRC(data, dataLen));
                Logger::puts_(hex);
            }
            Logger::puts_("\r\n");
        }

        data[0] = orig;
    }

    /* -------------------------------------------------------------------
     * getReply() — receive bytes from USART3 with per-byte timeout
     *
     * Original used: SERIALBMS.available() / SERIALBMS.read()
     * Port uses:     USART_SR RXNE flag with timeout on system_ms
     *
     * Returns number of bytes actually received.
     * ------------------------------------------------------------------- */
    static int getReply(uint8_t *data, int maxLen)
    {
        int numBytes = 0;
        if (Logger::isDebug()) Logger::puts_("Reply: ");

        while (numBytes < maxLen) {
            /* Wait up to BMS_BYTE_TIMEOUT_MS for next byte */
            uint32_t deadline = system_ms + BMS_BYTE_TIMEOUT_MS;
            bool got_byte = false;
            while (system_ms < deadline) {
                if (USART_SR(SERIALBMS_USART) & USART_SR_RXNE) {
                    data[numBytes] = (uint8_t)usart_recv(SERIALBMS_USART);
                    got_byte = true;
                    break;
                }
            }
            if (!got_byte) break; /* timeout — no more bytes coming */

            if (Logger::isDebug()) {
                char hex[4];
                snprintf_hex(hex, data[numBytes]);
                Logger::puts_(hex);
                Logger::putchar_(' ');
            }
            numBytes++;
        }
        /* Drain any overflow */
        while (USART_SR(SERIALBMS_USART) & USART_SR_RXNE)
            (void)usart_recv(SERIALBMS_USART);

        if (Logger::isDebug()) Logger::puts_("\r\n");
        return numBytes;
    }

    /* -------------------------------------------------------------------
     * sendDataWithReply() — send + receive with up to 3 retries
     *
     * Identical logic to original. delay() → delay_ms()
     * ------------------------------------------------------------------- */
    static int sendDataWithReply(uint8_t *data, uint8_t dataLen, bool isWrite,
                                 uint8_t *retData, int retLen)
    {
        int attempts = 1;
        int returnedLength = 0;
        while (attempts < 4) {
            sendData(data, dataLen, isWrite);
            delay_ms(2 * ((retLen / 8) + 1)); /* replaces delay() */
            returnedLength = getReply(retData, retLen);
            if (returnedLength == retLen) return returnedLength;
            attempts++;
        }
        return returnedLength;
    }

private:
    /* Mini hex formatter — avoids pulling in full printf for debug path */
    static void snprintf_hex(char *buf, uint8_t val)
    {
        const char *hx = "0123456789ABCDEF";
        buf[0] = hx[(val >> 4) & 0xF];
        buf[1] = hx[val & 0xF];
        buf[2] = '\0';
    }
};

#endif /* BMSUTIL_H */
