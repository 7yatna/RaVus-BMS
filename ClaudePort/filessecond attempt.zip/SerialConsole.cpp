/*
 * SerialConsole.cpp — STM32F103 port of TeslaBMSV2
 *
 * Accurate port of the original. Key replacements:
 *   SERIALCONSOLE.available()  → (USART_SR(SERIALCONSOLE_USART) & USART_SR_RXNE)
 *   SERIALCONSOLE.read()       → (int)usart_recv(SERIALCONSOLE_USART)
 *   Logger::console()          → unchanged
 *   extern BMSModuleManager bms → unchanged
 *
 * The loop() / printMenu() / handleShortCmd() logic is identical to original.
 */

#include "SerialConsole.h"
#include "Logger.h"
#include "BMSModuleManager.h"
#include <libopencm3/stm32/usart.h>

extern BMSModuleManager bms;

/* These were file-scope in original — kept the same */
static bool     printPrettyDisplay = false;
static uint32_t prettyCounter      = 0;
static int      whichDisplay       = 0;

/* External: declared in main.cpp */
extern volatile uint32_t system_ms;

SerialConsole::SerialConsole() {
    init();
}

void SerialConsole::init() {
    ptrBuffer          = 0;
    state              = STATE_ROOT_MENU;
    loopcount          = 0;
    cancel             = false;
    printPrettyDisplay = false;
    prettyCounter      = 0;
    whichDisplay       = 0;
}

/* -----------------------------------------------------------------------
 * loop() — replaces the Arduino serialEvent() + millis() pretty-print timer
 *
 * Original called loop() from the main Arduino loop().
 * This version is also called from main.cpp's while(1) loop.
 *
 * SERIALCONSOLE.available() → USART_SR RXNE flag
 * SERIALCONSOLE.read()      → usart_recv()
 * ----------------------------------------------------------------------- */
void SerialConsole::loop()
{
    /* Poll USART1 RX for incoming console bytes */
    while (USART_SR(SERIALCONSOLE_USART) & USART_SR_RXNE) {
        serialEvent();
    }

    /* Pretty display — every 5 seconds (replaces millis() comparison) */
    if (printPrettyDisplay && (system_ms - prettyCounter) >= 5000) {
        prettyCounter = system_ms;
        if (whichDisplay == 0) bms.printPackSummary();
        else                   bms.printPackDetails(2);
    }
}

/* -----------------------------------------------------------------------
 * printMenu() — identical to original
 * ----------------------------------------------------------------------- */
void SerialConsole::printMenu()
{
    Logger::console("\n*************SYSTEM MENU *****************");
    Logger::console("Enable line endings of some sort (LF, CR, CRLF)");
    Logger::console("Most commands case sensitive\n");
    Logger::console("GENERAL SYSTEM CONFIGURATION\n");
    Logger::console("   h = help (displays this message)");
    Logger::console("   S = Sleep all boards");
    Logger::console("   W = Wake up all boards");
    Logger::console("   C = Clear all board faults");
    Logger::console("   F = Find all connected boards");
    Logger::console("   R = Renumber connected boards in sequence");
    Logger::console("   B = Attempt balancing for 5 seconds");
    Logger::console("   p = Toggle output of pack summary every 5 seconds");
    Logger::console("   d = Toggle output of pack details every 5 seconds");
    Logger::console("   LOGLEVEL=%i - set log level (0=debug, 1=info, 2=warn, 3=error, 4=off)",
                    (int)Logger::getLogLevel());
}

/* -----------------------------------------------------------------------
 * serialEvent() — read one byte from USART1
 * Replaces: SERIALCONSOLE.read()
 * ----------------------------------------------------------------------- */
void SerialConsole::serialEvent()
{
    int incoming = (int)usart_recv(SERIALCONSOLE_USART);

    if (incoming == 10 || incoming == 13) {
        handleConsoleCmd();
        ptrBuffer = 0;
    } else {
        cmdBuffer[ptrBuffer++] = (unsigned char)incoming;
        if (ptrBuffer > 79) ptrBuffer = 79;
    }
}

/* -----------------------------------------------------------------------
 * handleConsoleCmd() — identical to original
 * ----------------------------------------------------------------------- */
void SerialConsole::handleConsoleCmd()
{
    if (state == STATE_ROOT_MENU) {
        if (ptrBuffer == 1) {
            handleShortCmd();
        }
        /* Multi-char commands can be added here (handleConfigCmd) */
    }
}

/* -----------------------------------------------------------------------
 * handleShortCmd() — identical to original
 * ----------------------------------------------------------------------- */
void SerialConsole::handleShortCmd()
{
    switch (cmdBuffer[0]) {
    case 'h':
    case '?':
    case 'H':
        printMenu();
        break;
    case 'S':
        Logger::console("Sleeping all connected boards");
        bms.sleepBoards();
        break;
    case 'W':
        Logger::console("Waking up all connected boards");
        bms.wakeBoards();
        break;
    case 'C':
        Logger::console("Clearing all faults");
        bms.clearFaults();
        break;
    case 'F':
        bms.findBoards();
        break;
    case 'R':
        Logger::console("Renumbering all boards.");
        bms.renumberBoardIDs();
        break;
    case 'B':
        /* Original had this commented out — matching that behaviour */
        /* bms.balanceCells(50, 1); */
        break;
    case 'p':
        if (whichDisplay == 1 && printPrettyDisplay) whichDisplay = 0;
        else {
            printPrettyDisplay = !printPrettyDisplay;
            if (printPrettyDisplay) Logger::console("Enabling pack summary display, 5 second interval");
            else                    Logger::console("No longer displaying pack summary.");
        }
        break;
    case 'd':
        if (whichDisplay == 0 && printPrettyDisplay) whichDisplay = 1;
        else {
            printPrettyDisplay = !printPrettyDisplay;
            whichDisplay = 1;
            if (printPrettyDisplay) Logger::console("Enabling pack details display, 5 second interval");
            else                    Logger::console("No longer displaying pack details.");
        }
        break;
    default:
        break;
    }
}
