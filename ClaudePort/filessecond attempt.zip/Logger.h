#pragma once
/*
 * Logger.h — STM32F103 port of TeslaBMSV2 Logger
 *
 * Preserves the exact same static class interface as the original.
 * All output goes to USART1 (PA9/PA10 @ 115200 baud).
 *
 * Original used Arduino's Serial.print() with custom format specifiers:
 *   %s %d %f %z %x %X %b %B %l %c %t %T
 * All are faithfully reproduced here.
 *
 * millis() → system_ms (volatile uint32_t, incremented by SysTick ISR)
 */

#ifndef LOGGER_H_
#define LOGGER_H_

#include <stdint.h>
#include <stdarg.h>
#include <stdbool.h>

/* Forward declaration - system_ms is defined in main.cpp */
extern volatile uint32_t system_ms;

class Logger {
public:
    enum LogLevel {
        Debug = 0, Info = 1, Warn = 2, Error = 3, Off = 4
    };

    static void debug(const char *format, ...);
    static void info(const char *format, ...);
    static void warn(const char *format, ...);
    static void error(const char *format, ...);
    static void console(const char *format, ...);
    static void setLoglevel(LogLevel level);
    static LogLevel getLogLevel();
    static uint32_t getLastLogTime();
    static bool isDebug();

    /* Low-level output helpers (used by BMSUtil and SerialConsole) */
    static void putchar_(char c);
    static void puts_(const char *s);

private:
    static LogLevel logLevel;
    static uint32_t lastLogTime;

    static void log(LogLevel level, const char *format, va_list args);
    static void logMessage(const char *format, va_list args);
};

#endif /* LOGGER_H_ */
