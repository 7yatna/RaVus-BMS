# TeslaBMSV2 — STM32F103C8T6 (Blue Pill) Port

Faithful port of [Tom-evnut/TeslaBMSV2](https://github.com/Tom-evnut/TeslaBMSV2)
from **Teensy 3.2** (MK20DX256 Cortex-M4) to **STM32F103C8T6** (Blue Pill, Cortex-M3)
using **libopencm3**.

---

## Hardware Differences

| | Teensy 3.2 | Blue Pill STM32F103C8T6 |
|---|---|---|
| Core | Cortex-M4 | Cortex-M3 |
| Clock | 96 MHz | 72 MHz |
| Flash | 256 KB | **64 KB** |
| RAM | 64 KB | **20 KB** |
| FPU | Yes | **No** (soft-float) |
| ADC | **16-bit** | **12-bit** (scaled ×16 in code) |
| EEPROM | 2 KB internal | **Flash emulation** |

---

## Pin Mapping

| Function | Teensy 3.2 | Blue Pill (STM32F103) |
|---|---|---|
| Debug console TX | USB Serial | **PA9** (USART1 TX, 115200) |
| Debug console RX | USB Serial | **PA10** (USART1 RX) |
| BMS module bus TX | Serial3 TX | **PB10** (USART3 TX, 612500) |
| BMS module bus RX | Serial3 RX | **PB11** (USART3 RX) |
| CAN TX | CAN TX (FlexCAN) | **PB9** (CAN1 TX, remapped) |
| CAN RX | CAN RX (FlexCAN) | **PB8** (CAN1 RX, remapped) |
| Current sensor ACUR1 | A1 (pin 15) | **PA0** (ADC_IN0) |
| Current sensor ACUR2 | A0 (pin 14) | **PA1** (ADC_IN1) |
| IN1 | Pin 17 | **PB0** |
| IN2 | Pin 16 | **PB1** |
| IN3 | Pin 18 | **PB3** |
| IN4 / CP pilot | Pin 19 | **PB4** (EXTI4) |
| OUT1 discharge contactor | Pin 11 | **PA8** |
| OUT2 main contactor | Pin 12 | **PB5** |
| OUT3 charge relay | Pin 20 | **PB6** |
| OUT4 precharge/neg | Pin 21 | **PB7** |
| LED | Pin 13 | **PC13** (active LOW) |

> **CAN remap**: CAN1 is remapped to PB8/PB9 via AFIO because the default
> CAN pins (PA11/PA12) conflict with USB on the Blue Pill.

---

## Library / API Replacements

| Teensy / Arduino | STM32 / libopencm3 |
|---|---|
| `ADC.h` (pedvide 16-bit) | `libopencm3/stm32/adc.h` — 12-bit, scaled ×16 |
| `FlexCAN.h` | `libopencm3/stm32/can.h` — bxCAN |
| `Filters.h` FilterOnePole LOWPASS | Inline IIR: `α·x + (1-α)·state` |
| `EEPROM.get/put(0, settings)` | Flash page erase + word-program |
| `EEPROM.update(1000, SOC)` | Flash word write at fixed offset |
| `EEPROM.read(1000)` | Flash word read |
| `millis()` | `system_ms` (SysTick ISR, volatile uint32_t) |
| `delay(n)` | `delay_ms(n)` — spins on `system_ms` |
| `micros()` | `system_ms * 1000` (coarse) |
| `attachInterrupt(IN4, isrCP, CHANGE)` | EXTI4 on PB4 |
| `WDOG_*` (Kinetis watchdog) | `iwdg_*` (STM32 independent watchdog) |
| `Serial2` (Nextion display) | Route to USART2 (PA2/PA3) if needed |
| `PMC_LVDSC*` (low-voltage detect) | Not available — SOC saved every 60 s |
| `RCM_SRS*` (reset cause) | Not ported (Teensy-specific) |

---

## Key Porting Notes

### ADC Scaling
The original used Teensy's 16-bit ADC (`max = 65535`). The current sensor
formula uses `offset1`/`offset2` and `convlow`/`convhigh` in raw ADC units:
```
RawCur = (value - offset) * conv / 1000000
```
The STM32 ADC is 12-bit (0–4095). In `main.cpp` we scale the raw reading
×16 before applying the formula so the existing calibration values in
`settings.offset1/2` and `settings.convlow/high` remain **unchanged**.

### Temperature Math
The Steinhart-Hart formula and all magic constants in `BMSModule.cpp` are
preserved **exactly** from the original — including the asymmetric
correction offsets `+2` and `+9` for the two thermistors.

### Voltage Math
Cell voltage and module voltage scaling factors are preserved exactly:
- Cell: `raw * 0.000381493`
- Module: `raw * 0.0020346293922562`

### Flash EEPROM
The Blue Pill has no internal EEPROM. Settings are stored in the last
2 KB flash page (`0x0800F800`). **Note:** The STM32F103C8T6 datasheet
says 64 KB, but many chips actually have 128 KB — check with `make size`.

For production use, replace the simple flash write with a proper
EEPROM emulation library (wear levelling). The current implementation
erases the page on every save.

### SOC Persistence
The original saved SOC to `EEPROM.update(1000, SOC)` triggered by a
low-voltage detector ISR. The STM32 port saves SOC every 60 seconds
in the main loop instead. This is safe for normal operation.

### CP Pilot (IN4 interrupt)
`attachInterrupt(IN4, isrCP, CHANGE)` → EXTI4 on PB4. The original
used `micros()` for pulse timing; the STM32 port uses `system_ms * 1000`
as a coarse approximation. For more accurate CP detection, enable the
DWT cycle counter and use it for microsecond resolution.

### Nextion Display (Serial2)
The original sent data to a Nextion display via `Serial2`. This is
**not included** in the core port. If you have a Nextion connected,
initialise USART2 (PA2/PA3) at 115200 baud and route the display
output there.

### Serial CAN expansion
The original included `Serial_CAN_Module_TeensyS2.h`. This library is
not ported. If you use a serial CAN adapter, wire it to USART2 and
implement the protocol.

---

## Build Instructions

```bash
# 1. Install the ARM toolchain
sudo apt install gcc-arm-none-eabi binutils-arm-none-eabi

# 2. Clone and build libopencm3
git clone https://github.com/libopencm3/libopencm3.git
cd libopencm3 && make TARGETS=stm32/f1 && cd ..

# 3. Build the firmware
make

# 4. Check size (must fit in 64 KB Flash / 20 KB RAM)
make size
```

### Flash via ST-Link
```bash
make flash
```

### Flash via Black Magic Probe
```bash
make flash_bmp BMP_PORT=/dev/ttyACM0
```

---

## File Structure

```
TeslaBMS_STM32/
├── Makefile
├── README.md
├── include/
│   ├── config.h          — pin map, register defs, EEPROMSettings struct
│   ├── Logger.h          — static Logger class (same interface as original)
│   ├── BMSUtil.h         — BMS bus protocol (header-only, same as original)
│   ├── BMSModule.h       — single BMS module (same interface as original)
│   ├── BMSModuleManager.h— bus manager (same interface as original)
│   └── SerialConsole.h   — console (same interface as original)
└── src/
    ├── main.cpp          — replaces TeslaBMSV2.ino (setup + loop)
    ├── Logger.cpp        — USART1 output, all original format specifiers
    ├── BMSModule.cpp     — near-verbatim port
    ├── BMSModuleManager.cpp — near-verbatim port
    └── SerialConsole.cpp — near-verbatim port
```

---

## Console Commands (unchanged from original)

Connect at **115200 8N1** to PA9 (TX) / PA10 (RX).

| Key | Action |
|---|---|
| `h` / `H` / `?` | Help menu |
| `S` | Sleep all boards |
| `W` | Wake all boards |
| `C` | Clear all faults |
| `F` | Find all boards |
| `R` | Renumber boards |
| `p` | Toggle pack summary (5 s interval) |
| `d` | Toggle pack details (5 s interval) |

---

## License

MIT — same as original TeslaBMSV2.
