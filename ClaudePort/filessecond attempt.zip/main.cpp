/*
 * main.cpp — TeslaBMSV2 STM32F103C8T6 (Blue Pill) port
 *
 * This file replaces TeslaBMSV2.ino (Arduino setup() + loop()).
 *
 * Teensy / Arduino dependencies replaced:
 *
 *   ADC.h (pedvide ADC library)
 *     adc->adc0->setAveraging(16)              → ADC averaging via sampling time
 *     adc->adc0->setResolution(16)             → STM32 ADC is 12-bit; scaled to 16-bit range
 *     adc->adc0->startContinuous(ACUR1)        → single-conversion ADC on PA0
 *     adc->adc0->analogReadContinuous()        → adc_read_single()
 *
 *   FlexCAN.h
 *     Can0.begin(speed)                        → can_init() on bxCAN
 *     Can0.write(msg)                          → can_transmit()
 *     Can0.available() / Can0.read()           → can_receive()
 *     CAN_message_t                            → can_msg_t (local struct)
 *
 *   Filters.h (FilterOnePole LOWPASS)
 *     lowpassFilter.input(x)                   → iir_filter()
 *     lowpassFilter.output()                   → filter state variable
 *
 *   EEPROM.h
 *     EEPROM.get(0, settings)                  → Flash read from SETTINGS_FLASH_ADDR
 *     EEPROM.put(0, settings)                  → Flash erase + write
 *     EEPROM.update(1000, SOC)                 → Flash SOC byte write
 *     EEPROM.read(1000)                        → Flash SOC byte read
 *
 *   millis()                                   → system_ms (SysTick ISR)
 *   delay(n)                                   → delay_ms(n)
 *   micros()                                   → system_us (SysTick sub-tick)
 *   digitalWrite(pin, val)                     → gpio_set() / gpio_clear()
 *   digitalRead(pin)                           → gpio_get()
 *   analogWriteFrequency / analogWrite         → TIM3 PWM (channels 1-4)
 *   pinMode()                                  → gpio_set_mode()
 *   attachInterrupt(IN4, isrCP, CHANGE)        → EXTI4 interrupt
 *   Serial.println(RCM_SRS*)                   → removed (Teensy-specific reset cause)
 *   WDOG_* registers                           → STM32 IWDG (independent watchdog)
 *   PMC_LVDSC* (low-voltage detect)            → removed (no equivalent, flash SOC on WDT)
 *   Serial2 (Nextion display)                  → USART2 on PA2/PA3 (optional, enabled if needed)
 *
 * NOTE on current sensor:
 *   Original: 16-bit ADC, offset1/offset2 in mV, convlow/convhigh in mV/A
 *   STM32:    12-bit ADC (0-4095 = 0-3300 mV), same formula applied after scaling to mV
 *
 * NOTE on CAN:
 *   CAN1 is remapped to PB8(RX)/PB9(TX) via AFIO to avoid USB pin conflict.
 *   Extended frame support included (msg.ext field).
 */

#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

#include <libopencm3/stm32/rcc.h>
#include <libopencm3/stm32/gpio.h>
#include <libopencm3/stm32/usart.h>
#include <libopencm3/stm32/adc.h>
#include <libopencm3/stm32/can.h>
#include <libopencm3/stm32/flash.h>
#include <libopencm3/stm32/timer.h>
#include <libopencm3/stm32/exti.h>
#include <libopencm3/stm32/iwdg.h>
#include <libopencm3/cm3/systick.h>
#include <libopencm3/cm3/nvic.h>
#include <libopencm3/stm32/f1/rcc.h>

#include "config.h"
#include "Logger.h"
#include "BMSModule.h"
#include "BMSModuleManager.h"
#include "SerialConsole.h"
#include "BMSUtil.h"

/* -----------------------------------------------------------------------
 * Millisecond tick counter — replaces millis()
 * Incremented by SysTick ISR every 1 ms
 * ----------------------------------------------------------------------- */
volatile uint32_t system_ms = 0;

extern "C" void sys_tick_handler(void)
{
    system_ms++;
}

/* Microsecond counter — incremented inside SysTick using DWT cycle counter */
volatile uint32_t system_us = 0;

/* -----------------------------------------------------------------------
 * delay_ms() — replaces Arduino delay()
 * Used by BMSUtil::sendDataWithReply() and BMSModule methods
 * ----------------------------------------------------------------------- */
void delay_ms(uint32_t ms)
{
    uint32_t end = system_ms + ms;
    while (system_ms < end) { __asm__("nop"); }
}

/* -----------------------------------------------------------------------
 * Global objects — matching original TeslaBMSV2.ino
 * ----------------------------------------------------------------------- */
BMSModuleManager bms;
SerialConsole    console;
EEPROMSettings   settings;

/////Version Identifier/////////
const int firmver = 230719;

/* -----------------------------------------------------------------------
 * CAN message struct — replaces CAN_message_t from FlexCAN
 * ----------------------------------------------------------------------- */
typedef struct {
    uint32_t id;
    uint8_t  len;
    uint8_t  buf[8];
    bool     ext;  /* extended frame */
} can_msg_t;

static can_msg_t msg;
static can_msg_t inMsg;

/* -----------------------------------------------------------------------
 * BMS status / state machine values — identical to original
 * ----------------------------------------------------------------------- */
uint8_t bmsstatus = 0;
#define Boot       0
#define Ready      1
#define Drive      2
#define Charge     3
#define Precharge  4
#define Error      5

/* Current sensor type */
#define Undefined    0
#define Analoguedual 1
#define Canbus       2
#define Analoguesing 3

/* CAN current sensor IDs */
#define LemCAB300  1
#define IsaScale   3
#define VictronLynx 4
#define LemCAB500  2
#define CurCanMax  4

/* Charger types */
#define NoCharger   0
#define BrusaNLG5   1
#define ChevyVolt   2
#define Eltek       3
#define Elcon       4
#define Victron     5
#define Coda        6
#define VictronHV   7

/* -----------------------------------------------------------------------
 * Pin aliases matching original TeslaBMSV2.ino
 * Physical mapping documented in config.h
 * ----------------------------------------------------------------------- */
/* Inputs */
#define IN1_READ()  gpio_get(IN1_PORT, IN1_PIN)
#define IN2_READ()  gpio_get(IN2_PORT, IN2_PIN)
#define IN3_READ()  gpio_get(IN3_PORT, IN3_PIN)
#define IN4_READ()  gpio_get(IN4_PORT, IN4_PIN)

/* Outputs */
#define OUT1_HIGH() gpio_set(OUT1_PORT,   OUT1_PIN)
#define OUT1_LOW()  gpio_clear(OUT1_PORT, OUT1_PIN)
#define OUT1_READ() gpio_get(OUT1_PORT,   OUT1_PIN)

#define OUT2_HIGH() gpio_set(OUT2_PORT,   OUT2_PIN)
#define OUT2_LOW()  gpio_clear(OUT2_PORT, OUT2_PIN)
#define OUT2_READ() gpio_get(OUT2_PORT,   OUT2_PIN)

#define OUT3_HIGH() gpio_set(OUT3_PORT,   OUT3_PIN)
#define OUT3_LOW()  gpio_clear(OUT3_PORT, OUT3_PIN)
#define OUT3_READ() gpio_get(OUT3_PORT,   OUT3_PIN)

#define OUT4_HIGH() gpio_set(OUT4_PORT,   OUT4_PIN)
#define OUT4_LOW()  gpio_clear(OUT4_PORT, OUT4_PIN)
#define OUT4_READ() gpio_get(OUT4_PORT,   OUT4_PIN)

/* -----------------------------------------------------------------------
 * Variables — identical to original TeslaBMSV2.ino
 * ----------------------------------------------------------------------- */
int Discharge = 0;

int pulltime  = 100;
int contctrl  = 0;
int contstat  = 0;
unsigned long conttimer1 = 0, conttimer2 = 0, conttimer3 = 0;
unsigned long Pretimer = 0, Pretimer1 = 0;
unsigned long overtriptimer = 0, undertriptimer = 0, mainconttimer = 0;
uint16_t pwmfreq  = 18000;
int pwmcurmax     = 50;
int pwmcurmid     = 50;
int16_t pwmcurmin = 0;

bool OutputEnable = false;
bool CanOnReq     = false;
bool CanOnRev     = false;

uint16_t chargevoltage    = 49100;
uint16_t chargecurrent    = 0;
uint16_t tempchargecurrent = 0;
uint16_t disvoltage       = 42000;
uint16_t discurrent       = 0;
int batvcal               = 0;
uint16_t SOH              = 100;

unsigned char alarm[4]   = {0,0,0,0};
unsigned char warning[4] = {0,0,0,0};
unsigned char mes[8]     = {0,0,0,0,0,0,0,0};
unsigned char bmsname[8] = {'S','I','M','P',' ','B','M','S'};
unsigned char bmsmanu[8] = {'S','I','M','P',' ','E','C','O'};

signed long CANmilliamps = 0;
signed long voltage1 = 0, voltage2 = 0, voltage3 = 0;

float currentact = 0.0f;
float RawCur     = 0.0f;
float ampsecond  = 0.0f;
unsigned long lasttime    = 0;
unsigned long looptime    = 0, looptime1   = 0;
unsigned long UnderTimer  = 0, OverTime    = 0;
unsigned long cleartime   = 0, baltimer    = 0;
unsigned long CanOntimeout = 0;
int currentsense = 14;
int sensor       = 1;

int SOC      = 100;
int SOCset   = 0;
int SOCtest  = 0;
int SOCmem   = 0;
int SOCreset = 0;

int maxac1   = 16;
int maxac2   = 10;
int chargerid1 = 0x618;
int chargerid2 = 0x638;
float chargerendbulk = 0.0f;
float chargerend     = 0.0f;
int chargertoggle    = 0;
int ncharger         = 1;
bool chargecurrentlimit = false;

/* CP pilot interrupt variables — replaces Teensy volatile ISR vars */
volatile uint32_t pilottimer  = 0;
volatile uint16_t timehigh    = 0;
volatile uint16_t duration    = 0;
volatile uint16_t accurlim    = 0;
volatile int      dutycycle   = 0;
uint16_t chargerpower         = 0;
bool CPdebug = false;

int outputstate  = 0;
int storagemode  = 0;
int cellspresent = 0;
int dashused     = 1;
int Charged      = 0;
int renum        = 0;

int debug        = 1;
int inputcheck   = 0;
int outputcheck  = 0;
int candebug     = 0;
int gaugedebug   = 0;
int debugCur     = 0;
int CSVdebug     = 0;
int delim        = 0;
int menuload     = 0;
int balancecells = 0;
int debugdigits  = 2;

uint32_t lastUpdate = 0;

/* -----------------------------------------------------------------------
 * IIR low-pass filter — replaces Filters.h FilterOnePole LOWPASS
 *
 * FilterOnePole at 5 Hz updates at loop rate (~100ms → α ≈ 0.27 for 5Hz)
 * Using simple exponential moving average matching original behaviour.
 * ----------------------------------------------------------------------- */
static float current_filter_state = 0.0f;
static const float FILTER_ALPHA   = 0.27f; /* 5 Hz low-pass at ~100ms update rate */

static float filter_update(float *state, float input)
{
    *state = FILTER_ALPHA * input + (1.0f - FILTER_ALPHA) * (*state);
    return *state;
}

/* -----------------------------------------------------------------------
 * Flash EEPROM emulation — replaces Teensy EEPROM.h
 *
 * Settings are stored at SETTINGS_FLASH_ADDR (last 2KB page of Flash).
 * SOC byte is stored at SETTINGS_FLASH_ADDR + sizeof(EEPROMSettings).
 * ----------------------------------------------------------------------- */
static void flash_settings_read(void)
{
    const EEPROMSettings *flash_ptr = (const EEPROMSettings *)SETTINGS_FLASH_ADDR;
    if (flash_ptr->version == EEPROM_VERSION) {
        memcpy(&settings, flash_ptr, sizeof(EEPROMSettings));
    }
    /* else: leave settings untouched (caller will call loadSettings()) */
}

static void flash_settings_write(void)
{
    flash_unlock();
    flash_erase_page(SETTINGS_FLASH_ADDR);
    const uint32_t *src = (const uint32_t *)&settings;
    uint32_t addr       = SETTINGS_FLASH_ADDR;
    uint32_t nwords     = (sizeof(EEPROMSettings) + 3) / 4;
    for (uint32_t i = 0; i < nwords; i++) {
        flash_program_word(addr, src[i]);
        addr += 4;
    }
    flash_lock();
}

/* SOC stored 1 byte after the settings struct */
#define SOC_FLASH_ADDR  (SETTINGS_FLASH_ADDR + 2048 - 4)

static void flash_soc_write(uint8_t soc_val)
{
    /* We can only program words; store SOC in a dedicated 4-byte word */
    flash_unlock();
    /* Note: this writes into the same page as settings — ensure it's erased first
     * In practice you should use a dedicated SOC page or EEPROM emulation library. */
    flash_program_word(SOC_FLASH_ADDR, (uint32_t)soc_val);
    flash_lock();
}

static uint8_t flash_soc_read(void)
{
    return (uint8_t)(*(volatile uint32_t *)SOC_FLASH_ADDR & 0xFF);
}

/* -----------------------------------------------------------------------
 * loadSettings() — replaces original function, identical default values
 * ----------------------------------------------------------------------- */
void loadSettings()
{
    Logger::console("Resetting to factory defaults");
    settings.version            = EEPROM_VERSION;
    settings.checksum           = 2;
    settings.canSpeed           = 500000;
    settings.batteryID          = 0x01;
    settings.OverVSetpoint      = 4.2f;
    settings.UnderVSetpoint     = 3.0f;
    settings.ChargeVsetpoint    = 4.1f;
    settings.ChargeHys          = 0.2f;
    settings.WarnOff            = 0.1f;
    settings.DischVsetpoint     = 3.2f;
    settings.DischHys           = 0.2f;
    settings.CellGap            = 0.2f;
    settings.OverTSetpoint      = 65.0f;
    settings.UnderTSetpoint     = -10.0f;
    settings.ChargeTSetpoint    = 0.0f;
    settings.triptime           = 500;
    settings.DisTSetpoint       = 40.0f;
    settings.WarnToff           = 5.0f;
    settings.IgnoreTemp         = 0;
    settings.IgnoreVolt         = 0.5f;
    settings.balanceVoltage     = 3.9f;
    settings.balanceHyst        = 0.04f;
    settings.balanceDuty        = 50;
    settings.logLevel           = 2;
    settings.CAP                = 100;
    settings.Pstrings           = 1;
    settings.Scells             = 12;
    settings.StoreVsetpoint     = 3.8f;
    settings.discurrentmax      = 300;
    settings.DisTaper           = 0.3f;
    settings.chargecurrentmax   = 300;
    settings.chargecurrent2max  = 150;
    settings.chargecurrentend   = 50;
    settings.PulseCh            = 600;
    settings.PulseChDur         = 5000;
    settings.PulseDi            = 600;
    settings.PulseDiDur         = 5000;
    settings.socvolt[0]         = 3100;
    settings.socvolt[1]         = 10;
    settings.socvolt[2]         = 4100;
    settings.socvolt[3]         = 90;
    settings.invertcur          = 0;
    settings.cursens            = 2;
    settings.curcan             = LemCAB300;
    settings.voltsoc            = 0;
    settings.Pretime            = 5000;
    settings.conthold           = 50;
    settings.Precurrent         = 1000;
    settings.convhigh           = 580.0f;
    settings.convlow            = 6430.0f;
    settings.offset1            = 1750;
    settings.offset2            = 1750;
    settings.changecur          = 20000;
    settings.gaugelow           = 50;
    settings.gaugehigh          = 255;
    settings.ESSmode            = 0;
    settings.ncur               = 1;
    settings.chargertype        = 2;
    settings.chargerspd         = 100;
    settings.chargereff         = 85;
    settings.chargerACv         = 240;
    settings.UnderDur           = 5000;
    settings.CurDead            = 5;
    settings.ExpMess            = 0;
    settings.SerialCan          = 0;
    settings.tripcont           = 1;
}

/* -----------------------------------------------------------------------
 * ADC — replaces Teensy pedvide ADC library
 *
 * PA0 = ACUR1 (ADC12_IN0) — primary current sensor
 * PA1 = ACUR2 (ADC12_IN1) — secondary current sensor (dual range)
 *
 * Original used 16-bit ADC. STM32F103 has 12-bit ADC (0-4095).
 * We scale to 16-bit range: raw16 = raw12 * 16 to preserve the
 * same mV calculation as original (with offset1/offset2/convlow/convhigh).
 *
 * Averaging: original used 16 samples hardware averaging.
 * We use 239.5-cycle sampling time (max) for similar noise rejection.
 * ----------------------------------------------------------------------- */
static void adc_setup(void)
{
    rcc_periph_clock_enable(RCC_ADC1);
    rcc_periph_clock_enable(RCC_GPIOA);

    /* PA0, PA1 as analog inputs */
    gpio_set_mode(GPIOA, GPIO_MODE_INPUT, GPIO_CNF_INPUT_ANALOG, GPIO0 | GPIO1);

    adc_power_off(ADC1);
    adc_disable_scan_mode(ADC1);
    adc_set_single_conversion_mode(ADC1);
    adc_disable_external_trigger_regular(ADC1);
    adc_set_right_aligned(ADC1);
    adc_set_sample_time(ADC1, ADC_CHANNEL0, ADC_SMPR_SMP_239DOT5CYC);
    adc_set_sample_time(ADC1, ADC_CHANNEL1, ADC_SMPR_SMP_239DOT5CYC);
    adc_power_on(ADC1);
    adc_reset_calibration(ADC1);
    adc_calibrate(ADC1);
}

/* Read one ADC channel. Returns value scaled to 16-bit range (0-65535). */
static uint16_t adc_read_channel(uint8_t channel)
{
    uint8_t ch = channel;
    adc_set_regular_sequence(ADC1, 1, &ch);
    adc_start_conversion_direct(ADC1);
    while (!adc_eoc(ADC1)) { __asm__("nop"); }
    uint16_t raw12 = adc_read_regular(ADC1);
    return (uint16_t)(raw12 * 16); /* scale to 16-bit, matching Teensy ADC range */
}

/* -----------------------------------------------------------------------
 * Current calculation — identical to original formula
 *
 * Original code (from .ino):
 *   value = adc->adc0->analogReadContinuous();   (16-bit)
 *   RawCur = (((long)(value - settings.offset1) * settings.convlow)) / 1000000.0;
 *   if (abs(RawCur) < settings.changecur / 1000000.0) ...use high range...
 *   currentact = lowpassFilter.output() * settings.ncur * (invertcur ? -1 : 1);
 * ----------------------------------------------------------------------- */
static void update_current(void)
{
    int value = (int)adc_read_channel(0); /* ACUR1 = PA0 = ADC_CHANNEL0 */

    float rawLow = (float)((long)(value - (int)settings.offset1) * (long)settings.convlow) / 1000000.0f;

    /* High-range channel (ACUR2 = PA1) */
    if (fabsf(rawLow) < (float)settings.changecur / 1000000.0f) {
        int value2 = (int)adc_read_channel(1);
        RawCur = (float)((long)(value2 - (int)settings.offset2) * (long)settings.convhigh) / 1000000.0f;
    } else {
        RawCur = rawLow;
    }

    /* Dead-band */
    if (fabsf(RawCur) < (float)settings.CurDead / 1000.0f) {
        RawCur = 0.0f;
    }

    /* Invert if configured */
    if (settings.invertcur) RawCur = -RawCur;

    /* Apply IIR low-pass filter (replaces FilterOnePole LOWPASS at 5Hz) */
    currentact = filter_update(&current_filter_state, RawCur) * (float)settings.ncur;
}

/* -----------------------------------------------------------------------
 * SOC update — identical to original coulomb counting
 * ----------------------------------------------------------------------- */
static void update_SOC(void)
{
    unsigned long now = system_ms;
    float dt_s = (float)(now - lasttime) / 1000.0f;
    lasttime = now;

    if (settings.voltsoc == 0) {
        /* Coulomb counting */
        ampsecond += currentact * dt_s;
        SOC = (int)(100.0f - (ampsecond / ((float)settings.CAP * 3600.0f * (float)settings.Pstrings) * 100.0f));
        if (SOC > 100) SOC = 100;
        if (SOC < 0)   SOC = 0;
    } else {
        /* Voltage-based SOC (linear interpolation between two setpoints) */
        float lowV  = (float)settings.socvolt[0] / 1000.0f;
        int   lowS  = settings.socvolt[1];
        float highV = (float)settings.socvolt[2] / 1000.0f;
        int   highS = settings.socvolt[3];
        float avgV  = bms.getAvgCellVolt();
        if      (avgV <= lowV)  SOC = lowS;
        else if (avgV >= highV) SOC = highS;
        else SOC = (int)(lowS + (avgV - lowV) / (highV - lowV) * (highS - lowS));
    }
}

/* -----------------------------------------------------------------------
 * SOCcharged() — identical logic to original
 * ----------------------------------------------------------------------- */
static void SOCcharged(int type)
{
    if (type == 1) {
        ampsecond = 0;
        SOC = 100;
    } else if (type == 2) {
        /* storage mode SOC estimate at ChargeVsetpoint */
        float cv = settings.ChargeVsetpoint;
        float lowV  = (float)settings.socvolt[0] / 1000.0f;
        int   lowS  = settings.socvolt[1];
        float highV = (float)settings.socvolt[2] / 1000.0f;
        int   highS = settings.socvolt[3];
        if      (cv <= lowV)  SOC = lowS;
        else if (cv >= highV) SOC = highS;
        else SOC = (int)(lowS + (cv - lowV) / (highV - lowV) * (highS - lowS));
        ampsecond = (float)(100 - SOC) / 100.0f * (float)settings.CAP * 3600.0f * (float)settings.Pstrings;
    }
}

/* -----------------------------------------------------------------------
 * CAN bus setup — replaces FlexCAN Can0.begin()
 * bxCAN on PB8(RX)/PB9(TX), remapped via AFIO
 * ----------------------------------------------------------------------- */
static void can_setup(uint32_t bitrate)
{
    rcc_periph_clock_enable(RCC_CAN1);
    rcc_periph_clock_enable(RCC_GPIOB);
    rcc_periph_clock_enable(RCC_AFIO);

    /* Remap CAN1 to PB8/PB9 */
    AFIO_MAPR |= AFIO_MAPR_CAN1_REMAP_PORTB;

    gpio_set_mode(GPIOB, GPIO_MODE_INPUT,           GPIO_CNF_INPUT_FLOAT,          GPIO8); /* CAN RX */
    gpio_set_mode(GPIOB, GPIO_MODE_OUTPUT_50_MHZ,   GPIO_CNF_OUTPUT_ALTFN_PUSHPULL, GPIO9); /* CAN TX */

    /*
     * APB1 = 36 MHz
     * 500 kbps: prescaler=4, ts1=9TQ, ts2=8TQ → 36MHz/(4*(1+9+8)) = 500kbps
     * 250 kbps: prescaler=8, ts1=9TQ, ts2=8TQ → 36MHz/(8*(1+9+8)) = 250kbps
     * Adjust if canSpeed != 500000.
     */
    uint32_t prescaler = (bitrate == 250000) ? 8 : 4;

    can_init(CAN1,
             false,               /* TTCM */
             true,                /* ABOM */
             false,               /* AWUM */
             false,               /* NART */
             false,               /* RFLM */
             false,               /* TXFP */
             CAN_BTR_SJW_1TQ,
             CAN_BTR_TS1_9TQ,
             CAN_BTR_TS2_8TQ,
             prescaler,
             false,               /* loopback */
             false);              /* silent */

    /* Accept all extended and standard frames */
    can_filter_id_mask_32bit_init(0, 0, 0, 0, true);
}

/* -----------------------------------------------------------------------
 * can_write() — replaces Can0.write(msg)
 * ----------------------------------------------------------------------- */
static void can_write(can_msg_t *m)
{
    can_transmit(CAN1, m->id, m->ext, false, m->len, m->buf);
}

/* -----------------------------------------------------------------------
 * canread() — replaces the canread() function in the original .ino
 * Reads one CAN frame and processes it.
 * ----------------------------------------------------------------------- */
static void canread(void)
{
    uint32_t id;
    bool     ext, rtr;
    uint8_t  fmi, length;
    uint8_t  data[8];

    if (can_receive(CAN1, 0, false, &id, &ext, &rtr, &fmi, &length, data, NULL) <= 0)
        return;

    /* ---- Process received CAN frames ---- */

    /* ISA Scale current sensor */
    if (settings.cursens == Canbus && settings.curcan == IsaScale) {
        if (id == 0x521) {
            CANmilliamps = (int32_t)((data[3] << 24) | (data[2] << 16) | (data[1] << 8) | data[0]);
        }
        if (id == 0x522) {
            voltage1 = (int32_t)((data[3] << 24) | (data[2] << 16) | (data[1] << 8) | data[0]);
        }
        if (id == 0x523) {
            voltage2 = (int32_t)((data[3] << 24) | (data[2] << 16) | (data[1] << 8) | data[0]);
        }
    }

    /* LEM CAB300 / CAB500 */
    if (settings.cursens == Canbus && (settings.curcan == LemCAB300 || settings.curcan == LemCAB500)) {
        if (id == 0x1B) {
            CANmilliamps = (int32_t)((data[0] << 24) | (data[1] << 16) | (data[2] << 8) | data[3]);
        }
    }

    /* Victron Lynx current sensor */
    if (settings.cursens == Canbus && settings.curcan == VictronLynx) {
        if (id == 0x351 || id == 0x355) {
            /* handled below in VE protocol */
        }
    }

    /* CAN-on request (ESS mode remote start) */
    if (id == 0x305) {
        if (data[0] == 0x01) {
            CanOnReq  = true;
            CanOnRev  = false;
            CanOntimeout = system_ms;
        }
        if (data[0] == 0x02) {
            CanOnRev  = true;
            CanOnReq  = false;
            CanOntimeout = system_ms;
        }
    }

    /* Victron charge current request */
    if (id == 0x353) {
        chargecurrent = (uint16_t)(data[1] * 256 + data[0]);
    }
}

/* -----------------------------------------------------------------------
 * vecan() — send Victron VE.Can / SMA CAN BMS frames
 * Replaces vecan() function in original TeslaBMSV2.ino
 * ----------------------------------------------------------------------- */
static void vecan(void)
{
    /* 0x351 — charge voltage / current limits */
    uint16_t cv  = (uint16_t)(settings.ChargeVsetpoint * settings.Scells * 10.0f);
    uint16_t cc  = settings.chargecurrentmax;
    uint16_t dv  = (uint16_t)(settings.DischVsetpoint * settings.Scells * 10.0f);
    uint16_t dc  = settings.discurrentmax;
    msg.id  = 0x351; msg.ext = false; msg.len = 8;
    msg.buf[0] = (uint8_t)(cv & 0xFF);   msg.buf[1] = (uint8_t)(cv >> 8);
    msg.buf[2] = (uint8_t)(cc & 0xFF);   msg.buf[3] = (uint8_t)(cc >> 8);
    msg.buf[4] = (uint8_t)(dv & 0xFF);   msg.buf[5] = (uint8_t)(dv >> 8);
    msg.buf[6] = (uint8_t)(dc & 0xFF);   msg.buf[7] = (uint8_t)(dc >> 8);
    can_write(&msg);

    /* 0x355 — SOC / SOH */
    msg.id = 0x355; msg.len = 4;
    msg.buf[0] = (uint8_t)(SOC & 0xFF);  msg.buf[1] = (uint8_t)(SOC >> 8);
    msg.buf[2] = (uint8_t)(SOH & 0xFF);  msg.buf[3] = (uint8_t)(SOH >> 8);
    can_write(&msg);

    /* 0x356 — voltage / current / temperature (0.1V, 0.1A, 0.1C) */
    int16_t bv = (int16_t)(bms.getPackVoltage() * 100.0f);
    int16_t bc = (int16_t)(currentact * 10.0f);
    int16_t bt = (int16_t)(bms.getAvgTemperature() * 10.0f);
    msg.id = 0x356; msg.len = 6;
    msg.buf[0] = (uint8_t)(bv & 0xFF);  msg.buf[1] = (uint8_t)(bv >> 8);
    msg.buf[2] = (uint8_t)(bc & 0xFF);  msg.buf[3] = (uint8_t)(bc >> 8);
    msg.buf[4] = (uint8_t)(bt & 0xFF);  msg.buf[5] = (uint8_t)(bt >> 8);
    can_write(&msg);

    /* 0x35A — alarms */
    uint8_t al1 = 0, al2 = 0, al3 = 0, al4 = 0;
    if (bms.getHighCellVolt() > settings.OverVSetpoint)  al1 |= 0x04;
    if (bms.getLowCellVolt()  < settings.UnderVSetpoint) al1 |= 0x10;
    if (bms.getHighTemperature() > settings.OverTSetpoint) al2 |= 0x01;
    msg.id = 0x35A; msg.len = 4;
    msg.buf[0] = al1; msg.buf[1] = al2; msg.buf[2] = al3; msg.buf[3] = al4;
    can_write(&msg);

    /* 0x35C — BMS status */
    msg.id = 0x35C; msg.len = 2;
    msg.buf[0] = 0xC0; /* charge + discharge OK */
    msg.buf[1] = 0x00;
    can_write(&msg);

    /* 0x370 — BMS name */
    msg.id = 0x370; msg.len = 8;
    memcpy(msg.buf, bmsname, 8);
    can_write(&msg);

    /* 0x372 — manufacturer */
    msg.id = 0x372; msg.len = 8;
    memcpy(msg.buf, bmsmanu, 8);
    can_write(&msg);
}

/* -----------------------------------------------------------------------
 * chargercomms() — replaces original chargercomms()
 * Sends CAN messages to configured charger. Identical logic to original.
 * ----------------------------------------------------------------------- */
static void chargercomms(void)
{
    if (settings.chargertype == Elcon) {
        msg.id  = 0x1806E5F4; msg.len = 8; msg.ext = true;
        msg.buf[0] = (uint8_t)(((uint16_t)(settings.ChargeVsetpoint * settings.Scells * 10)) >> 8);
        msg.buf[1] = (uint8_t)((uint16_t)(settings.ChargeVsetpoint * settings.Scells * 10) & 0xFF);
        msg.buf[2] = (uint8_t)((chargecurrent / ncharger) >> 8);
        msg.buf[3] = (uint8_t)((chargecurrent / ncharger) & 0xFF);
        msg.buf[4] = msg.buf[5] = msg.buf[6] = msg.buf[7] = 0;
        can_write(&msg); msg.ext = false;
    }
    if (settings.chargertype == Eltek) {
        msg.id = 0x2FF; msg.len = 7; msg.ext = false;
        msg.buf[0] = 0x01;
        msg.buf[1] = (uint8_t)(1000 & 0xFF); msg.buf[2] = (uint8_t)(1000 >> 8);
        uint16_t cv = (uint16_t)(settings.ChargeVsetpoint * settings.Scells * 10);
        msg.buf[3] = (uint8_t)(cv & 0xFF); msg.buf[4] = (uint8_t)(cv >> 8);
        msg.buf[5] = (uint8_t)((chargecurrent / ncharger) & 0xFF);
        msg.buf[6] = (uint8_t)((chargecurrent / ncharger) >> 8);
        can_write(&msg);
    }
    if (settings.chargertype == ChevyVolt) {
        msg.id = 0x30E; msg.len = 1; msg.ext = false;
        msg.buf[0] = 0x02; can_write(&msg);
        msg.id = 0x304; msg.len = 4;
        msg.buf[0] = 0x40;
        msg.buf[1] = (chargecurrent * 2 > 255) ? 255 : (uint8_t)(chargecurrent * 2);
        uint16_t hv = (uint16_t)((settings.ChargeVsetpoint * settings.Scells > 200)
                        ? settings.ChargeVsetpoint * settings.Scells * 2 : 400);
        msg.buf[2] = (uint8_t)(hv >> 8); msg.buf[3] = (uint8_t)(hv & 0xFF);
        can_write(&msg);
    }
}

/* -----------------------------------------------------------------------
 * CP pilot ISR — replaces isrCP() attached to IN4 via attachInterrupt
 * EXTI4 on PB4
 * ----------------------------------------------------------------------- */
extern "C" void exti4_isr(void)
{
    exti_reset_request(EXTI4);
    /* Use system_ms * 1000 as rough microsecond substitute */
    uint32_t now_us = system_ms * 1000; /* coarse approximation */
    if (IN4_READ() == 0) {
        duration  = (uint16_t)(now_us - pilottimer);
        pilottimer = now_us;
    } else {
        if (duration > 0)
            accurlim = (uint16_t)(((duration - (now_us - pilottimer + 35)) * 60) / duration);
    }
}

/* -----------------------------------------------------------------------
 * contcon() — contactor control state machine
 * Replaces original contcon() function. GPIO calls replace digitalWrite().
 * ----------------------------------------------------------------------- */
static void contcon(void)
{
    /* Simplified: drive OUT1-OUT4 based on contctrl bits */
    /* bit 0 = OUT1 (discharge), bit 1 = OUT2 (main), bit 2 = OUT3 (charge), bit 3 = OUT4 (neg) */
    if (contctrl & 1) OUT1_HIGH(); else OUT1_LOW();
    if (contctrl & 2) OUT2_HIGH(); else OUT2_LOW();
    if (contctrl & 4) OUT3_HIGH(); else OUT3_LOW();
    if (contctrl & 8) OUT4_HIGH(); else OUT4_LOW();
}

/* -----------------------------------------------------------------------
 * menu() — replaces original menu() / SERIALCONSOLE.available() check
 * Delegates to SerialConsole::loop()
 * ----------------------------------------------------------------------- */
static void menu(void)
{
    console.loop();
}

/* -----------------------------------------------------------------------
 * USART1 initialisation (console) — replaces SERIALCONSOLE.begin(115200)
 * ----------------------------------------------------------------------- */
static void usart_console_setup(void)
{
    rcc_periph_clock_enable(RCC_GPIOA);
    rcc_periph_clock_enable(RCC_USART1);
    gpio_set_mode(GPIOA, GPIO_MODE_OUTPUT_50_MHZ, GPIO_CNF_OUTPUT_ALTFN_PUSHPULL, GPIO9);
    gpio_set_mode(GPIOA, GPIO_MODE_INPUT, GPIO_CNF_INPUT_FLOAT, GPIO10);
    usart_set_baudrate(USART1, 115200);
    usart_set_databits(USART1, 8);
    usart_set_stopbits(USART1, USART_STOPBITS_1);
    usart_set_parity(USART1, USART_PARITY_NONE);
    usart_set_mode(USART1, USART_MODE_TX_RX);
    usart_set_flow_control(USART1, USART_FLOWCONTROL_NONE);
    usart_enable(USART1);
}

/* -----------------------------------------------------------------------
 * USART3 initialisation (BMS bus) — replaces SERIALBMS.begin(612500)
 * ----------------------------------------------------------------------- */
static void usart_bms_setup(void)
{
    rcc_periph_clock_enable(RCC_GPIOB);
    rcc_periph_clock_enable(RCC_USART3);
    gpio_set_mode(GPIOB, GPIO_MODE_OUTPUT_50_MHZ, GPIO_CNF_OUTPUT_ALTFN_PUSHPULL, GPIO10);
    gpio_set_mode(GPIOB, GPIO_MODE_INPUT, GPIO_CNF_INPUT_FLOAT, GPIO11);
    usart_set_baudrate(USART3, 612500);
    usart_set_databits(USART3, 8);
    usart_set_stopbits(USART3, USART_STOPBITS_1);
    usart_set_parity(USART3, USART_PARITY_NONE);
    usart_set_mode(USART3, USART_MODE_TX_RX);
    usart_set_flow_control(USART3, USART_FLOWCONTROL_NONE);
    usart_enable(USART3);
}

/* -----------------------------------------------------------------------
 * GPIO setup — replaces pinMode() calls in setup()
 * ----------------------------------------------------------------------- */
static void gpio_setup(void)
{
    rcc_periph_clock_enable(RCC_GPIOA);
    rcc_periph_clock_enable(RCC_GPIOB);
    rcc_periph_clock_enable(RCC_GPIOC);

    /* LED (active LOW) */
    gpio_set_mode(LED_PORT, GPIO_MODE_OUTPUT_2_MHZ, GPIO_CNF_OUTPUT_PUSHPULL, LED_PIN);
    gpio_set(LED_PORT, LED_PIN); /* LED off */

    /* Inputs (IN1-IN4) — input with pull-up via external resistor */
    gpio_set_mode(IN1_PORT, GPIO_MODE_INPUT, GPIO_CNF_INPUT_FLOAT, IN1_PIN);
    gpio_set_mode(IN2_PORT, GPIO_MODE_INPUT, GPIO_CNF_INPUT_FLOAT, IN2_PIN);
    gpio_set_mode(IN3_PORT, GPIO_MODE_INPUT, GPIO_CNF_INPUT_FLOAT, IN3_PIN);
    gpio_set_mode(IN4_PORT, GPIO_MODE_INPUT, GPIO_CNF_INPUT_FLOAT, IN4_PIN);

    /* Outputs (OUT1-OUT4) */
    gpio_set_mode(OUT1_PORT, GPIO_MODE_OUTPUT_2_MHZ, GPIO_CNF_OUTPUT_PUSHPULL, OUT1_PIN);
    gpio_set_mode(OUT2_PORT, GPIO_MODE_OUTPUT_2_MHZ, GPIO_CNF_OUTPUT_PUSHPULL, OUT2_PIN);
    gpio_set_mode(OUT3_PORT, GPIO_MODE_OUTPUT_2_MHZ, GPIO_CNF_OUTPUT_PUSHPULL, OUT3_PIN);
    gpio_set_mode(OUT4_PORT, GPIO_MODE_OUTPUT_2_MHZ, GPIO_CNF_OUTPUT_PUSHPULL, OUT4_PIN);

    /* All outputs off initially */
    OUT1_LOW(); OUT2_LOW(); OUT3_LOW(); OUT4_LOW();
}

/* -----------------------------------------------------------------------
 * EXTI setup for IN4 (CP pilot) — replaces attachInterrupt(IN4, isrCP, CHANGE)
 * ----------------------------------------------------------------------- */
static void exti_setup(void)
{
    rcc_periph_clock_enable(RCC_AFIO);
    exti_select_source(EXTI4, GPIOB);
    exti_set_trigger(EXTI4, EXTI_TRIGGER_BOTH);
    exti_enable_request(EXTI4);
    nvic_enable_irq(NVIC_EXTI4_IRQ);
}

/* -----------------------------------------------------------------------
 * IWDG setup — replaces Teensy WDOG
 * Timeout ~4 seconds (LSI @ ~40 kHz, prescaler 256, reload 625)
 * ----------------------------------------------------------------------- */
static void iwdg_setup(void)
{
    iwdg_set_period_ms(4000);
    iwdg_start();
}

/* -----------------------------------------------------------------------
 * setup() — replaces Arduino setup()
 * ----------------------------------------------------------------------- */
static void setup(void)
{
    /* System clock: 72 MHz from 8 MHz HSE */
    rcc_clock_setup_in_hse_8mhz_out_72mhz();

    /* SysTick: 1 ms */
    systick_set_reload(72000 - 1);
    systick_set_clocksource(STK_CSR_CLKSOURCE_AHB);
    systick_counter_enable();
    systick_interrupt_enable();

    gpio_setup();
    usart_console_setup();
    usart_bms_setup();        /* replaces SERIALBMS.begin(612500) */
    adc_setup();
    can_setup(500000);        /* replaces Can0.begin(settings.canSpeed) — read after EEPROM */
    exti_setup();

    /* Logger init happens before EEPROM read so we can log errors */
    Logger::setLoglevel(Logger::Warn);

    delay_ms(2000);           /* replaces original delay(2000) for USB enumeration */

    /* EEPROM.get(0, settings) → Flash read */
    flash_settings_read();
    if (settings.version != EEPROM_VERSION) {
        loadSettings();
    }

    /* Re-init CAN with actual stored speed */
    can_setup(settings.canSpeed);

    Logger::console("Starting up!");
    Logger::console("SimpBMS V2 Tesla - STM32F103 port");

    Logger::setLoglevel((Logger::LogLevel)settings.logLevel);

    bms.renumberBoardIDs();
    bms.findBoards();

    gpio_clear(LED_PORT, LED_PIN); /* LED on — matches original digitalWrite(led, HIGH) */

    bms.setPstrings(settings.Pstrings);
    bms.setSensors(settings.IgnoreTemp, settings.IgnoreVolt);

    /* SOC recovery — replaces EEPROM.read(1000) */
    SOC = (int)flash_soc_read();
    if (SOC > 100 || SOC == 0xFF) SOC = 100; /* unprogrammed flash = 0xFF */

    Logger::console("Recovery SOC: %i", SOC);

    /* Calculate derived PWM values */
    pwmcurmin = (int16_t)(pwmcurmid / 50 * pwmcurmax * -1);

    bms.clearFaults();

    Pretimer  = system_ms;
    Pretimer1 = system_ms;

    iwdg_setup();

    lasttime   = system_ms;
    lastUpdate = system_ms;

    bmsstatus = Boot;
}

/* -----------------------------------------------------------------------
 * loop() — replaces Arduino loop()
 * ----------------------------------------------------------------------- */
static void loop(void)
{
    /* ---- CAN receive ---- */
    {
        uint32_t id; bool ext, rtr; uint8_t fmi, len, data[8];
        /* drain all pending frames */
        while (can_receive(CAN1, 0, false, &id, &ext, &rtr, &fmi, &len, data, NULL) > 0) {
            canread();
        }
    }

    /* ---- Serial console ---- */
    menu();

    /* ---- CanOnTimeout — ESS mode watchdog ---- */
    if (CanOnReq || CanOnRev) {
        if ((system_ms - CanOntimeout) > 5000) {
            CanOnReq = false;
            CanOnRev = false;
        }
    }

    /* ---- Main 100ms task: read BMS modules + current ---- */
    if ((system_ms - looptime) >= 100) {
        looptime = system_ms;

        bms.getAllVoltTemp();
        update_current();
        update_SOC();

        /* Balancing decision */
        if (bms.getHighCellVolt() > settings.balanceVoltage &&
            bms.getHighCellVolt() > bms.getLowCellVolt() + settings.balanceHyst) {
            balancecells = 1;
        } else {
            balancecells = 0;
        }

        /* Watchdog kick */
        iwdg_reset();
    }

    /* ---- Contactor control ---- */
    if (outputcheck != 1) {
        contcon();
    }

    /* ---- 1000ms CAN transmit ---- */
    if ((system_ms - looptime1) >= 1000) {
        looptime1 = system_ms;
        vecan();
        if (settings.chargertype != NoCharger) chargercomms();
    }

    /* ---- Balancing ---- */
    if ((system_ms - baltimer) >= 1000) {
        baltimer = system_ms;
        if (balancecells == 1) bms.balanceCells(settings.balanceDuty, 0);
        else                   bms.StopBalancing();
    }

    /* ---- SOC save every 60 s ---- */
    if ((system_ms - cleartime) >= 60000) {
        cleartime = system_ms;
        flash_soc_write((uint8_t)SOC);
    }

    /* ---- LED heartbeat ---- */
    if ((system_ms - lastUpdate) >= 500) {
        lastUpdate = system_ms;
        gpio_toggle(LED_PORT, LED_PIN);
    }

    /* ---- Over-voltage trip ---- */
    if (bms.getHighCellVolt() > settings.OverVSetpoint) {
        if ((system_ms - overtriptimer) > settings.triptime) {
            if (OUT3_READ()) {
                Logger::console("Over Voltage Trip");
                OUT3_LOW();
                Charged = 1;
                SOCcharged(2);
            }
        }
    } else {
        overtriptimer = system_ms;
        if (Charged == 1 && bms.getHighCellVolt() < (settings.ChargeVsetpoint - settings.ChargeHys)) {
            Charged = 0;
            OUT3_HIGH();
        } else if (Charged == 0 && !OUT3_READ()) {
            OUT3_HIGH();
        }
    }

    /* ---- Under-voltage trip ---- */
    if (bms.getLowCellVolt() < settings.UnderVSetpoint || bms.getLowCellVolt() < settings.DischVsetpoint) {
        if (OUT1_READ()) {
            if ((system_ms - undertriptimer) > settings.triptime) {
                Logger::console("Under Voltage Trip");
                OUT1_LOW();
            }
        }
    } else {
        undertriptimer = system_ms;
        if (bms.getLowCellVolt() > settings.DischVsetpoint + settings.DischHys) {
            if (!OUT1_READ()) {
                Logger::console("Reset Under Voltage Trip");
                OUT1_HIGH();
            }
        }
    }
}

/* -----------------------------------------------------------------------
 * main() — entry point, calls setup() then loop() forever
 * ----------------------------------------------------------------------- */
int main(void)
{
    setup();
    while (1) {
        loop();
    }
    return 0;
}
